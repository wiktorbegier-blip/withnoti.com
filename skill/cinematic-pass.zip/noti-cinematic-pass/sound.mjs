#!/usr/bin/env node
// The sound map: where each sound goes, worked out from the cuts, the camera moves and the scene's beats.
//
//   node sound.mjs <scene> plan    lists every cue (when, what kind, which file) and writes out/<scene>/cues.json
//   node sound.mjs <scene> mix     mixes the cues from the files in sounds/ into out/<scene>/sound.wav
//   then:  node render.mjs <scene> video --audio out/<scene>/sound.wav
//
//   option:  --look <name>   use looks/<name>.js instead of the look named after the scene
//
// No sound files come with this kit. Put your own in sounds/ (wav, mp3, m4a, aiff, flac or ogg), named as the look's
// `sound` list names them: with  sound: { cut: 'whoosh', screen: 'blip' }  a cut plays sounds/whoosh.wav and a beat of
// kind 'screen' plays sounds/blip.wav. A kind with no file is listed and left silent.
// An entry can say more:  cut: { file: 'whoosh', lead: 0.2, level: 0.6 }   lead: how long before the moment the file starts
// (a whoosh that peaks 0.2 s in wants lead 0.2, so its peak sits on the cut); level: how loud, 0 to 1.
//
// What gets a cue:
//   every cut after the first    kind 'cut', starting before the cut and ending after it, so the sound carries the eye across.
//                                A shot that arrives with in: 'snap', 'crash' or 'whip' gets that kind instead.
//   a long push (2.5 s or more, push 0.05 or more)  kind 'rise', ending on the next cut
//   every beat in the scene      its own kind (beats: [{ t, kind }]), on the frame it happens: never early.
//                                A beat with `for: 5` is a sound that runs that many seconds (wheels rolling, rain), looped if the file is shorter.
//   the whole length             'bed' (room tone, looped, quiet), 'music' (cut to length) and 'voice' if there is one
//
// What the mix does by itself:
//   a file used again within ten seconds is played a little higher or lower and a little louder or quieter, so it is not heard as a repeat
//   the music drops for a moment just before the key beat (the beat marked key: true, or else the one with the most punch): a breath, never silence
//   with a voice, the music sits well under it
//   the whole mix is set to the loudness phones and feeds expect (-14 LUFS, peaks under -1.5 dB)
import { existsSync, mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { dirname, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { HOUSE_MOVES } from './src/camera.js';

const ROOT = dirname(fileURLToPath(import.meta.url)), args = process.argv.slice(2);
const at = args.indexOf('--look'), lookName = at >= 0 ? args.splice(at, 2)[1] : null, [name, mode = 'plan'] = args;
const fail = (m) => { console.error(m); process.exit(2); };
if (!name || !/^[\w-]+$/.test(name) || !['plan', 'mix'].includes(mode)) fail('usage: node sound.mjs <scene> plan | mix   [--look name]');
for (const [dir, n] of [['scenes', name], ['looks', lookName || name]]) if (!existsSync(join(ROOT, dir, `${n}.js`))) fail(`No file at ${dir}/${n}.js`);
const scene = (await import(pathToFileURL(join(ROOT, 'scenes', `${name}.js`)).href)).default, look = (await import(pathToFileURL(join(ROOT, 'looks', `${lookName || name}.js`)).href)).default;

const EXT = ['wav', 'mp3', 'm4a', 'aiff', 'flac', 'ogg'], LEAD = { cut: 0.08, whip: 0.1 };
const entry = (kind) => { const e = look.sound?.[kind]; return !e ? null : typeof e === 'string' ? { file: e } : e; };
const fileFor = (kind) => { const base = entry(kind)?.file; if (!base) return null; for (const e of EXT) { const f = join(ROOT, 'sounds', `${base}.${e}`); if (existsSync(f)) return f; } return null; };
const dur = scene.duration, cues = [];
const shots = (scene.shots?.length ? scene.shots : [{ t: 0, cam: 'the camera' }]).map((s, i) => ({ ...s, ...(look.moves?.[i] ?? HOUSE_MOVES[i % HOUSE_MOVES.length]) })).sort((a, b) => a.t - b.t);
const cue = (t, kind, level, why, extra = {}) => { const e = entry(kind), lead = extra.whole ? 0 : e?.lead ?? LEAD[kind] ?? 0;
  cues.push({ t: +Math.max(0, t - lead).toFixed(2), moment: +t.toFixed(2), kind, level: e?.level ?? level, why, name: e?.file || null, file: fileFor(kind), ...extra }); };
const hasVoice = !!fileFor('voice');
shots.forEach((s, i) => {
  const end = shots[i + 1]?.t ?? dur, arrive = typeof s.in === 'string' ? s.in.replace('-left', '') : '';
  if (i > 0) { if (['snap', 'crash', 'whip'].includes(arrive)) cue(s.t, arrive, arrive === 'crash' ? 0.9 : 0.6, `the camera ${arrive === 'whip' ? 'whips to' : 'lands on'} "${s.cam}"`); else cue(s.t, 'cut', 0.5, `cut to "${s.cam}"`); }
  if (end - s.t >= 2.5 && Math.abs(s.push || 0) >= 0.05) cue(end - Math.min(2, end - s.t), 'rise', 0.35, `the push on "${s.cam}" builds to the ${shots[i + 1] ? 'cut' : 'end'}`);
});
const beats = scene.beats || [];
// a beat can last: { t: 0.5, kind: 'roll', for: 5 } is a sound that runs for five seconds (wheels, rain, a fan), looped if the file is shorter
for (const b of beats) if (b.kind) cue(b.t, b.kind, b.for ? 0.4 : b.punch ? 0.85 : 0.6, b.for ? `runs for ${b.for} s` : 'a beat in the scene', b.for ? { lasts: +b.for, loop: true } : {});
cue(0, 'bed', 0.22, 'the room, under everything', { whole: true, loop: true });
cue(0, 'music', hasVoice ? 0.28 : 0.5, hasVoice ? 'music, well under the voice' : 'music, under everything', { whole: true });
if (entry('voice')) cue(0, 'voice', 1, 'the voice, over everything', { whole: true });
cues.sort((a, b) => a.t - b.t);

// the same file again within ten seconds: shift its pitch and level a step, so the ear does not hear a repeat
const STEP = [[0, 0], [-1, -1.5], [2, 1], [-2, -1], [1, 1.5]], last = new Map();
for (const c of cues) { if (c.whole || !c.name) continue; const seen = last.get(c.name); const n = seen && c.t - seen.t < 10 ? seen.n + 1 : 0; [c.semitones, c.db] = STEP[n % STEP.length]; last.set(c.name, { t: c.t, n }); }
// the breath before the key moment: the music drops for 0.4 s and is back on the beat
const key = beats.find((b) => b.key) || beats.filter((b) => b.punch).sort((a, b) => (b.punch === true ? 1 : b.punch) - (a.punch === true ? 1 : a.punch))[0] || null;
const hole = key && key.t > 0.6 ? { from: +(key.t - 0.4).toFixed(2), to: +key.t.toFixed(2) } : null;

mkdirSync(join(ROOT, 'out', name), { recursive: true });
const rel = (f) => (f ? f.slice(ROOT.length + 1) : null), events = cues.filter((c) => !c.whole);
writeFileSync(join(ROOT, 'out', name, 'cues.json'), JSON.stringify({ scene: name, duration: dur, music_hole: hole, cues: cues.map((c) => ({ ...c, file: rel(c.file) })) }, null, 2) + '\n');
console.log(`Sound map for "${name}" (${dur} s):`);
for (const c of cues) { const vary = c.semitones || c.db ? `  (${c.semitones > 0 ? '+' : ''}${c.semitones} semitones, ${c.db > 0 ? '+' : ''}${c.db} dB: a repeat)` : '';
  console.log(`  ${c.whole ? 'whole'.padStart(6) : (c.t.toFixed(2) + ' s').padStart(6)}  ${c.kind.padEnd(8)} ${(c.file ? rel(c.file) : c.name ? `no file sounds/${c.name}.*` : 'not named in the look').padEnd(30)} ${c.why}${vary}`); }
if (hole) console.log(`  The music drops from ${hole.from} to ${hole.to} s, the breath before the key moment at ${key.t} s.`);
for (let i = 1; i < events.length; i++) if (events[i].moment - events[i - 1].moment < 0.1) console.log(`  Two sounds on one moment (${events[i - 1].kind} and ${events[i].kind} at ${events[i].moment} s): keep one.`);
console.log(`\n${events.length} sounds in ${dur} s: ${(events.length / dur).toFixed(1)} a second. For scale: a film with no speech holds attention at 2 to 4 a second, one with speech at 0.5 to 1.5 under the voice.`);
const unnamed = [...new Set(cues.filter((c) => !c.name && c.kind !== 'voice').map((c) => c.kind))], nofile = [...new Set(cues.filter((c) => c.name && !c.file).map((c) => `${c.kind} (sounds/${c.name}.*)`))];
if (unnamed.length) console.log(`Silent, not named yet: ${unnamed.join(', ')}. Name each in the look's "sound" list.`);
if (nofile.length) console.log(`Silent, no file yet: ${nofile.join(', ')}. Put a file with that name in sounds/.`);
// a whole-length sound that is shorter than the film would stop dead: say so, and let it fade out where it ends
const lengthOf = (file) => { const r = spawnSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', file], { encoding: 'utf8' }); return r.status === 0 ? parseFloat(r.stdout) : NaN; };
for (const c of cues) { if (!c.whole || c.loop || !c.file) continue; const len = lengthOf(c.file); if (Number.isFinite(len) && len < dur - 0.1) { c.ends = +len.toFixed(2);
  console.log(`  The ${c.kind} file is ${len.toFixed(1)} s and the film is ${dur} s: it fades out at ${len.toFixed(1)} s and the rest has none. Use a longer file, or name it as 'bed' if it can loop.`); } }
console.log(`\nout/${name}/cues.json`);
if (mode === 'plan') process.exit(0);

const use = cues.filter((c) => c.file);
if (!use.length) fail('\nNothing to mix: no cue has a sound file yet.');
if (spawnSync('ffmpeg', ['-version']).status !== 0) fail('ffmpeg was not found.');
const inputs = [], filters = [];
use.forEach((c, i) => {
  if (c.loop) inputs.push('-stream_loop', '-1'); inputs.push('-i', c.file);
  const pitch = c.semitones ? `,asetrate=${Math.round(48000 * 2 ** (c.semitones / 12))},aresample=48000` : '', level = (c.level * 10 ** ((c.db || 0) / 20)).toFixed(3);
  const breath = c.kind === 'music' && hole ? `,volume=eval=frame:volume='1-0.85*min(1,max(0,(t-${hole.from})/0.06))*min(1,max(0,(${hole.to + 0.06}-t)/0.06))'` : '';
  const stop = c.ends ?? dur, fade = c.whole ? `,afade=t=in:d=0.3,afade=t=out:st=${Math.max(0, stop - 0.6).toFixed(2)}:d=0.6` : '';
  const keep = Math.min(dur - c.t, c.lasts ?? Infinity), ends = c.lasts ? `,afade=t=in:d=0.15,afade=t=out:st=${Math.max(0, keep - 0.3).toFixed(2)}:d=0.3` : '';
  filters.push(`[${i}:a]aresample=48000,aformat=channel_layouts=stereo${pitch},atrim=0:${keep.toFixed(2)}${ends},adelay=${Math.round(c.t * 1000)}:all=1,volume=${level}${breath}${fade}[a${i}]`);
});
filters.push(`${use.map((_, i) => `[a${i}]`).join('')}amix=inputs=${use.length}:normalize=0:duration=longest,atrim=0:${dur}[out]`);
const pre = join(ROOT, 'out', name, 'premix.wav'), out = join(ROOT, 'out', name, 'sound.wav'), wav = ['-ar', '48000', '-ac', '2', '-c:a', 'pcm_s16le'];
if (spawnSync('ffmpeg', ['-y', '-loglevel', 'error', ...inputs, '-filter_complex', filters.join(';'), '-map', '[out]', ...wav, pre], { stdio: 'inherit' }).status !== 0) fail('The mix failed (see above).');
// loudness: measure the whole mix, then turn it up or down by one amount (nothing is squeezed), as far as the peaks allow
const probe = spawnSync('ffmpeg', ['-hide_banner', '-nostats', '-i', pre, '-af', 'loudnorm=I=-14:TP=-1.5:print_format=json', '-f', 'null', '-'], { encoding: 'utf8' });
const m = /\{[^{}]*"input_i"[^{}]*\}/.exec(probe.stderr || ''), read = m ? JSON.parse(m[0]) : null, loud = read ? +read.input_i : NaN, peak = read ? +read.input_tp : NaN;
let gain = 0, note = 'loudness not measured; left as mixed';
if (Number.isFinite(loud) && Number.isFinite(peak)) { gain = Math.min(-14 - loud, -1.5 - peak); const now = loud + gain;
  note = `${now.toFixed(1)} LUFS, peaks at ${(peak + gain).toFixed(1)} dB` + (now < -14.5 ? ` (the target is -14; the peaks stop it there: one sound is much louder than the rest, lower its level)` : ''); }
if (spawnSync('ffmpeg', ['-y', '-loglevel', 'error', '-i', pre, '-af', `volume=${gain.toFixed(2)}dB`, ...wav, out], { stdio: 'inherit' }).status !== 0) fail('The mix failed (see above).');
rmSync(pre, { force: true });
console.log(`out/${name}/sound.wav   (${use.length} of ${cues.length} cues; ${note})\nNext: node render.mjs ${name} video --audio out/${name}/sound.wav`);
