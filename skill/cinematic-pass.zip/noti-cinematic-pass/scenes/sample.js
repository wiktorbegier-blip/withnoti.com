// The sample scene: someone at a desk, typing. The screen lights up (2.9 s); they stop, lean back, and put their hands on their head (5 s).
// It is deliberately plain: grey blocks, no light of its own, no camera moves. It is the "before".
//
// A scene is a file that default-exports:
//   duration   seconds
//   build({ THREE, scene, RoundedBoxGeometry })   makes the objects and returns { cameras, parts }
//                cameras  { name: { pos: [x, y, z], look: [x, y, z], fov, focus: 'part name' } }   (metres; y is up)
//                parts    { name: object }   the things the look can paint, light and focus on
//   update(t)  puts everything where it is at second t. It must depend on t alone: frames are drawn in any order, some more than once.
//   shots      [{ t, cam }]   which camera is on from when
//   beats      [{ t, kind, punch }]   moments that matter: the camera can accent them (punch) and the sound map gives them a sound (kind)

let P = null;   // the moving parts, kept for update()
const ease = (x) => { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); };

export default {
  duration: 8,
  shots: [{ t: 0, cam: 'wide' }, { t: 2.3, cam: 'over' }, { t: 4.3, cam: 'close' }],     // the room, what they see, how they take it
  beats: [{ t: 2.9, kind: 'screen', punch: 0.5 }, { t: 5.1, kind: 'move' }],

  build({ THREE, scene, RoundedBoxGeometry }) {
    const grey = new THREE.MeshStandardMaterial({ color: 0x9a9a9a, roughness: 1 });
    const parts = {};
    const group = (name, parent = scene) => { const g = new THREE.Group(); parent.add(g); if (name) parts[name] = g; return g; };
    const box = (parent, w, h, d, x, y, z, r = 0.012) => { const m = new THREE.Mesh(new RoundedBoxGeometry(w, h, d, 3, Math.min(r, w / 2.01, h / 2.01, d / 2.01)), grey); m.position.set(x, y, z); parent.add(m); return m; };

    // the room: the person faces -z (towards the monitor); the wall with the shelf and the lamp is behind them
    box(group('floor'), 9, 0.1, 9, 0, -0.05, 0, 0);
    const wall = group('wall'); box(wall, 9, 3.2, 0.1, 0, 1.6, 2.7, 0); box(wall, 9, 3.2, 0.1, 0, 1.6, -2.7, 0); box(wall, 0.1, 3.2, 9, -3, 1.6, 0, 0);
    const desk = group('desk'); box(desk, 1.5, 0.04, 0.75, 0, 0.74, 0); for (const [x, z] of [[-0.7, -0.32], [0.7, -0.32], [-0.7, 0.32], [0.7, 0.32]]) box(desk, 0.05, 0.72, 0.05, x, 0.36, z);
    const monitor = group('monitor'); box(monitor, 0.62, 0.38, 0.03, 0, 1.12, -0.22); box(monitor, 0.06, 0.2, 0.05, 0, 0.86, -0.24); box(monitor, 0.24, 0.015, 0.16, 0, 0.768, -0.24);
    box(group('screen'), 0.58, 0.34, 0.004, 0, 1.12, -0.203, 0.002);
    box(group('keyboard'), 0.42, 0.02, 0.14, 0, 0.77, 0.12, 0.006);
    const mug = group('mug'), cup = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.036, 0.09, 24), grey); cup.position.set(0.5, 0.805, 0.05); mug.add(cup);
    const chair = group('chair'); box(chair, 0.5, 0.06, 0.5, 0, 0.46, 0.74); box(chair, 0.5, 0.62, 0.06, 0, 0.82, 1.0); box(chair, 0.06, 0.44, 0.06, 0, 0.22, 0.74);
    const lamp = group('lamp'); box(lamp, 0.03, 1.5, 0.03, -1.15, 0.75, 1.95); box(lamp, 0.26, 0.03, 0.26, -1.15, 0.015, 1.95);
    const shade = group('shade'), cone = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.22, 0.26, 32, 1, true), grey.clone()); cone.material.side = THREE.DoubleSide; cone.position.set(-1.15, 1.58, 1.95); shade.add(cone);
    const shelf = group('shelf'); box(shelf, 1.7, 0.04, 0.24, 0.55, 1.55, 2.53);
    const books = group('books'); [0.26, 0.31, 0.22, 0.29, 0.24, 0.33, 0.2, 0.27].forEach((h, i) => box(books, 0.05 + (i % 3) * 0.012, h, 0.17, -0.1 + i * 0.085, 1.57 + h / 2, 2.53, 0.004));

    // the person: a seated block figure, built from pivots so update() can pose it
    const person = group('person'); person.position.set(0, 0, 0.7);
    const body = new THREE.Group(); body.position.set(0, 0.55, 0); person.add(body);                      // pivots at the hips
    box(body, 0.38, 0.5, 0.24, 0, 0.27, 0, 0.03);
    box(group('legs', person), 0.32, 0.12, 0.44, 0, 0.5, -0.24, 0.03);
    const neck = new THREE.Group(); neck.position.set(0, 0.54, 0); body.add(neck);
    const head = group('head', neck); box(head, 0.25, 0.27, 0.25, 0, 0.16, 0, 0.035);
    const hair = group('hair', neck); box(hair, 0.27, 0.08, 0.27, 0, 0.325, 0.006, 0.03); box(hair, 0.27, 0.2, 0.06, 0, 0.22, 0.125, 0.025);   // a cap of hair and the back of it
    const eyes = group('eyes', neck); box(eyes, 0.034, 0.052, 0.014, -0.055, 0.19, -0.128, 0.004); box(eyes, 0.034, 0.052, 0.014, 0.055, 0.19, -0.128, 0.004);
    const arm = (side) => { const shoulder = new THREE.Group(); shoulder.position.set(side * 0.235, 0.46, 0); body.add(shoulder); box(shoulder, 0.09, 0.28, 0.09, 0, -0.13, 0, 0.03);
      const elbow = new THREE.Group(); elbow.position.set(0, -0.27, 0); shoulder.add(elbow); box(elbow, 0.08, 0.27, 0.08, 0, -0.125, 0, 0.03); box(elbow, 0.085, 0.07, 0.1, 0, -0.28, 0, 0.02); return { shoulder, elbow }; };
    const sleeves = group('arms', body); const L = arm(-1), R = arm(1); for (const a of [L, R]) sleeves.add(a.shoulder);
    P = { body, neck, L, R, screen: parts.screen };

    return {
      parts,
      cameras: {
        wide: { pos: [2.25, 1.45, -1.75], look: [0, 1.0, 0.35], fov: 34, focus: 'head' },
        close: { pos: [0.8, 1.4, -0.95], look: [0.02, 1.36, 0.7], fov: 30, focus: 'head' },
        over: { pos: [0.85, 1.62, 2.35], look: [0.02, 1.12, -0.1], fov: 30, focus: 'screen' },
      },
    };
  },

  update(t) {
    const stop = ease((t - 2.95) / 0.45), up = ease((t - 4.95) / 0.6), typing = 1 - stop;
    P.body.rotation.x = -0.1 * typing + 0.13 * stop + 0.05 * up;                         // leans in to type, back when it happens
    P.neck.rotation.x = -0.2 * typing + 0.1 * stop + 0.12 * up; P.neck.rotation.y = 0.05 * Math.sin(t * 0.8) * typing;
    for (const [a, phase, side] of [[P.L, 0, -1], [P.R, Math.PI, 1]]) {
      const tap = Math.sin(t * 15 + phase) * 0.05 * typing;
      a.shoulder.rotation.x = -0.55 * (1 - up) - 2.75 * up; a.shoulder.rotation.z = side * (0.05 + 0.5 * up);     // hands to the keyboard, then up to the head
      a.elbow.rotation.x = (-1.15 + tap - 0.25 * stop) * (1 - up);
      a.elbow.rotation.z = -side * 1.6 * up; a.elbow.rotation.y = side * 0.47 * up;                             // the forearms fold in, onto the head
    }
    P.screen.userData.glow = t < 2.9 ? 0.4 : 1 + 0.9 * Math.exp(-(t - 2.9) / 0.22);      // the screen lights up at 2.9 s: a lamp in the look follows this number
  },
};
