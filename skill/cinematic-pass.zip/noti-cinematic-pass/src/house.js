// The house look: how NōTI finishes its own films, as settings a look can start from.
//
//   import { houseLook } from '../src/house.js';
//   export default houseLook('dusk', { key: { from: [-2.4, 2.4, 1.6], at: 'head' }, rim: { from: [1.9, 2.4, -1.9] }, paint: { ... }, moves: [ ... ] });
//
// What it is, in one line: a warm room with one cool line. Lamps carry the picture; one indigo light draws the edges;
// the shadows are deep and the air is warm and dark, never grey. The numbers below are the ones our films use.
//   palette   warm (lamp light), cool (the one indigo line), dark (walls and air), wood (the surfaces light lands on)
//   key       a soft warm white, not orange: skin stays skin. The lamps are what is orange.
//   rim       the cool line, far stronger than the key, because it only ever touches an edge
//   fill      almost none: the lamps do the filling. If a shadow is too dark, add a lamp, not fill
//   air       the fog is dark brown, so distance reads as warmth and depth, not as mist
//   lens      a squeezed (anamorphic) lens: out-of-focus lights are upright ovals, bright things leave a faint cool streak
//             and a warm halo, the picture bends and the colours part a little at the edges. All of it small.

const lens = { subframes: 16, shutter: 0.5, aperture: 0.013, oval: 0.72, bloom: 0.3, vignette: 0.55, grain: 0.042, contrast: 0.2, saturation: 1.06, split: 0.5,
  fringe: 0.0016, distortion: 0.035, halation: 0.35, streak: 0.9, streakTint: '#806bff', lift: 0.012 };

export const house = {
  // dusk: the look as built. A last cool light from outside, the lamps already on.
  dusk: {
    palette: { warm: '#ffa052', cool: '#5a46ff', dark: '#140c08', wood: '#4a2b17', amber: '#ff9a4a' },
    rest: '#1c120c',
    key: { color: '#ffe2c4', power: 60, soft: 0.07 },
    rim: { color: 'cool', power: 160 },
    fill: 0.12, sky: '#1c1638', ground: '#0a0503',
    air: '#1a0e06', haze: 0.06, reflect: 0.35,
    lens,
  },
  // night: the same room later. Almost nothing from outside; the lamps carry everything.
  night: {
    palette: { warm: '#ff9648', cool: '#4f3cff', dark: '#100a06', wood: '#40240f', amber: '#ff9040' },
    rest: '#181008',
    key: { color: '#ffd9b4', power: 48, soft: 0.08 },
    rim: { color: 'cool', power: 110 },
    fill: 0.08, sky: '#120e28', ground: '#070402',
    air: '#140a05', haze: 0.07, reflect: 0.3,
    lens: { ...lens, bloom: 0.36, vignette: 0.6 },
  },
};

/** A look that starts from the house's and adds the scene's own: where the lights stand, what each part is painted, how each shot moves. */
export function houseLook(time, own = {}) {
  const base = house[time] || house.dusk, merged = { ...base, ...own };
  for (const group of ['palette', 'key', 'rim', 'lens']) merged[group] = { ...base[group], ...(own[group] || {}) };
  if (own.palette?.cool && !own.lens?.streakTint) merged.lens.streakTint = own.palette.cool;   // the streak is the cool line's colour
  return merged;
}
