// The finish: what turns a plain animation into a film frame.
//   paint   colour and material for each named part of the scene
//   light   a key light with soft shadows, a rim light from behind, a low fill, and lamps that really light the room
//   air     haze, so the room has depth and the background falls away; the room reflected in whatever is glossy
//   lens    every frame is the average of many slightly different ones (sub-frames): each sees the scene a moment later
//           (motion blur), from another point on the lens (depth of field), with the key light nudged (soft shadows)
//           and shifted by part of a pixel (clean edges). Then what a real lens adds: light that bleeds from the lamps,
//           a faint streak, a warm halo, colours that part slightly at the edges, a vignette, a grade and grain.
// Everything is set in a look file (looks/<name>.js). Nothing here knows about any particular scene.

const VS = 'varying vec2 vUv; void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }';
const halton = (i, b) => { let f = 1, r = 0; while (i > 0) { f /= b; r += f * (i % b); i = Math.floor(i / b); } return r; };
const disc = (i, n) => { const r = Math.sqrt((i + 0.5) / n), a = i * 2.399963229728653; return [r * Math.cos(a), r * Math.sin(a)]; };

/** Colour, material, lights and haze, from the look file. Returns what the lens needs to animate (the key, the lamps). */
export function dress(THREE, renderer, scene, parts, look) {
  scene.updateMatrixWorld(true);   // parts are measured below, so they have to be where the scene put them
  const pal = look.palette || {}, col = (c) => new THREE.Color(pal[c] ?? c ?? '#888888');
  const box = new THREE.Box3(), centre = (o, into = new THREE.Vector3()) => box.setFromObject(o).getCenter(into);
  const unknown = (what, name) => console.warn(`look: ${what} names a part that is not in the scene: "${name}" (have: ${Object.keys(parts).join(', ')})`);
  const origin = new THREE.Vector3(0, 1, 0), where = (p, fallback = origin) => { if (Array.isArray(p)) return new THREE.Vector3(p[0], p[1], p[2]); if (parts[p]) return centre(parts[p]); if (typeof p === 'string') unknown('a light', p); return fallback.clone(); };
  const depth = (o) => { let n = 0; for (let q = o; q && q.parent; q = q.parent) n++; return n; };
  const painted = new Set(), lamps = [], gated = [], follow = [], tied = [];
  // a place given as a part's name stays with that part as it moves (a light aimed at 'head' keeps aiming at the head)
  const place = (vec, p, fallback, offset = null) => { vec.copy(where(p, fallback)); if (offset) vec.add(offset); if (typeof p === 'string' && parts[p]) follow.push({ vec, part: parts[p], offset }); return vec; };
  // a light may say which cameras it is on for (only, not), and which lamp it dims and flashes with (with: 'shade')
  const gate = (light, L) => { if (L.only || L.not) gated.push({ light, only: L.only && [].concat(L.only), not: L.not && [].concat(L.not) });
    if (L.with && parts[L.with]) tied.push({ light, base: light.intensity, part: parts[L.with] }); else if (L.with) unknown('a light\'s "with"', L.with); return light; };
  let glowTex = null;   // a soft round glow, drawn once, for the halo round a lamp
  const halo = () => { if (glowTex) return glowTex; const c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d'), g = x.createRadialGradient(64, 64, 0, 64, 64, 64);
    g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.25, 'rgba(255,255,255,0.35)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, 128, 128); return (glowTex = new THREE.CanvasTexture(c)); };
  // a part inside another part keeps its own paint: the innermost name wins (a head inside a person stays a head)
  const order = Object.entries(look.paint || {}).sort(([a], [b]) => (parts[b] ? depth(parts[b]) : 0) - (parts[a] ? depth(parts[a]) : 0));
  for (const [name, p] of order) {
    const root = parts[name];
    if (!root) { console.warn(`look: no part called "${name}" in the scene (have: ${Object.keys(parts).join(', ')})`); continue; }
    // a glowing part is black under its glow unless it is given a colour too (then it still shows its shape)
    const mat = new THREE.MeshStandardMaterial({ color: col(p.glow ? (p.color ?? '#000000') : p.color), roughness: p.rough ?? 0.72, metalness: p.metal ?? 0, emissive: p.glow ? col(p.glow) : new THREE.Color(0), emissiveIntensity: p.glow ? (p.power ?? 1.5) : 0, side: p.glow ? THREE.DoubleSide : THREE.FrontSide });
    let both = null;   // the same paint for a mesh the scene made visible from both sides (an open shade, a sheet of paper)
    root.traverse((o) => { if (!o.isMesh || painted.has(o)) return; const twoSided = !p.glow && [].concat(o.material).some((m) => m?.side === THREE.DoubleSide);
      o.material = twoSided ? (both ||= Object.assign(mat.clone(), { side: THREE.DoubleSide })) : mat; o.castShadow = !p.glow; o.receiveShadow = !p.glow; painted.add(o); });
    if (p.glow) {   // a part that glows is also a lamp: it lights what is near it, and the air round it, and its light goes where it goes
      const light = new THREE.PointLight(col(p.glow), p.light ?? 6, p.reach ?? 6, 2); place(light.position, name, origin, p.lightAt ? new THREE.Vector3(...p.lightAt) : null); scene.add(light);
      let sprite = null;
      // the halo in the air round it: five times as wide as the part unless haloSize (in metres) says otherwise; each frame it stands
      // just in front of the part, towards the camera, so the part and what it is fixed to do not cut through it
      const radius = box.setFromObject(root).getSize(new THREE.Vector3()).length() / 2;
      if ((p.halo ?? 0.3) > 0) { sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: halo(), color: col(p.glow), transparent: true, opacity: p.halo ?? 0.3, blending: THREE.AdditiveBlending, depthWrite: false, fog: false })); sprite.scale.setScalar(p.haloSize ?? radius * 5); scene.add(sprite); }
      lamps.push({ root, mat, light, sprite, radius, at: new THREE.Vector3(), power: p.power ?? 1.5, strength: p.light ?? 6, halo: p.halo ?? 0.3 });
    }
  }
  // whatever was not named still must not stay raw: it takes the look's quiet colour. The scene's own lights go: the look lights it.
  const rest = new THREE.MeshStandardMaterial({ color: col(look.rest ?? '#2c2533'), roughness: 0.85 });
  scene.traverse((o) => { if (o.isMesh && !painted.has(o)) { o.material = rest; o.castShadow = o.receiveShadow = true; } if (o.isLight && !lamps.some((l) => l.light === o)) o.visible = false; });

  const K = look.key || {}, R = look.rim || {};
  const spot = (L, colour, power, angle, stand = null) => { const s = new THREE.SpotLight(col(L.color ?? colour), L.power ?? power, L.reach ?? 0, L.angle ?? angle, 0.8, 2); place(stand || s.position, L.from ?? [-2, 3, 2]); place(s.target.position, L.at ?? K.at ?? [0, 1, 0]); scene.add(s, s.target); return gate(s, L); };
  // only the key casts shadows: every other light shines through things
  const keyBase = new THREE.Vector3(), key = spot(K, 'warm', 60, 0.6, keyBase); key.position.copy(keyBase); key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048); key.shadow.bias = -0.0004; key.shadow.normalBias = 0.02; key.shadow.camera.near = 0.05; key.shadow.camera.far = 30;
  spot({ from: [2, 2.4, -2.5], ...R }, 'cool', 80, 0.7);
  // more lights, each with a job: an edge on the key's side, a bounce off a warm wall, a strip under a shelf.
  // Any light (these, the key, the rim) may say which cameras it is on for: only: ['close'] or not: ['over']. On a set the
  // lights are moved between set-ups for exactly this reason: a rim for one camera is a front light for the camera opposite.
  for (const L of look.lights || []) { if (L.kind === 'point') { const p = new THREE.PointLight(col(L.color ?? 'warm'), L.power ?? 2, L.reach ?? 8, 2); place(p.position, L.from ?? [0, 2, 0]); scene.add(gate(p, L)); } else spot(L, 'cool', 30, 0.5); }
  scene.add(new THREE.HemisphereLight(col(look.sky ?? 'cool'), col(look.ground ?? 'dark'), look.fill ?? 0.25));
  const air = col(look.air ?? 'dark'); scene.background = air.clone(); scene.fog = new THREE.FogExp2(air.clone(), look.haze ?? 0.04);
  // the room itself, photographed once and reflected in whatever is glossy (a desk top, a screen's edge, a mug)
  if ((look.reflect ?? 0) > 0) { const pm = new THREE.PMREMGenerator(renderer); scene.environment = pm.fromScene(scene, 0.04).texture; scene.environmentIntensity = look.reflect; pm.dispose(); }
  return { key, keyBase, soft: K.soft ?? 0.07, lamps, gated, follow, tied, centre };
}

/** The frame pipeline. render(n, each) draws n sub-frames (each(i, n) sets the scene and returns the camera) and shows their average, finished. */
export function makeLens(THREE, renderer, W, H, lens = {}) {
  const T = THREE.HalfFloatType, rt = (w, h, depth = false) => new THREE.WebGLRenderTarget(w, h, { type: T, depthBuffer: depth, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter });
  const bw = Math.max(8, W >> 2), bh = Math.max(8, H >> 2), frame = rt(W, H, true), acc = rt(W, H), bA = rt(bw, bh), bB = rt(bw, bh), cA = rt(bw >> 1, bh >> 1), cB = rt(bw >> 1, bh >> 1), sA = rt(bw >> 1, bh >> 1), sB = rt(bw >> 1, bh >> 1);
  const cam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1), quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2)), stage = new THREE.Scene(); stage.add(quad);
  const pass = (mat, target) => { quad.material = mat; renderer.setRenderTarget(target); renderer.render(stage, cam); };
  const flat = { depthTest: false, depthWrite: false, vertexShader: VS };
  const addU = { tex: { value: null }, w: { value: 1 } };
  const add = new THREE.ShaderMaterial({ ...flat, uniforms: addU, blending: THREE.CustomBlending, blendSrc: THREE.OneFactor, blendDst: THREE.OneFactor, blendEquation: THREE.AddEquation, fragmentShader: 'uniform sampler2D tex; uniform float w; varying vec2 vUv; void main() { gl_FragColor = vec4(texture2D(tex, vUv).rgb * w, 1.0); }' });
  const brightU = { tex: { value: null }, thr: { value: lens.bloomFrom ?? 1.0 } };
  const bright = new THREE.ShaderMaterial({ ...flat, uniforms: brightU, fragmentShader: 'uniform sampler2D tex; uniform float thr; varying vec2 vUv; void main() { vec3 c = texture2D(tex, vUv).rgb; float l = max(c.r, max(c.g, c.b)); gl_FragColor = vec4(c * smoothstep(thr, thr + 0.8, l), 1.0); }' });
  const blurU = { tex: { value: null }, dir: { value: new THREE.Vector2() } };
  const blur = new THREE.ShaderMaterial({ ...flat, uniforms: blurU, fragmentShader: 'uniform sampler2D tex; uniform vec2 dir; varying vec2 vUv; void main() { vec3 c = texture2D(tex, vUv).rgb * 0.227; c += (texture2D(tex, vUv + dir * 1.385).rgb + texture2D(tex, vUv - dir * 1.385).rgb) * 0.316; c += (texture2D(tex, vUv + dir * 3.231).rgb + texture2D(tex, vUv - dir * 3.231).rgb) * 0.070; gl_FragColor = vec4(c, 1.0); }' });
  const smear = (from, to, x, y) => { blurU.tex.value = from.texture; blurU.dir.value.set(x, y); pass(blur, to); };
  const outU = { tex: { value: acc.texture }, b0: { value: bA.texture }, b1: { value: cA.texture }, st: { value: sB.texture }, bloom: { value: lens.bloom ?? 0.4 }, exposure: { value: lens.exposure ?? 1 }, vig: { value: lens.vignette ?? 0.5 }, aspect: { value: W / H },
    contrast: { value: lens.contrast ?? 0.2 }, sat: { value: lens.saturation ?? 1.06 }, split: { value: lens.split ?? 0.4 }, grain: { value: lens.grain ?? 0.04 }, seed: { value: 0 }, fade: { value: 0 },
    dist: { value: lens.distortion ?? 0 }, fringe: { value: lens.fringe ?? 0 }, hal: { value: lens.halation ?? 0 }, streak: { value: lens.streak ?? 0 }, lift: { value: lens.lift ?? 0 },
    streakTint: { value: new THREE.Color(lens.streakTint ?? '#806bff') }, cool: { value: new THREE.Color(lens.shadowTint ?? '#2a3cff') }, warm: { value: new THREE.Color(lens.lightTint ?? '#ffb070') } };
  const out = new THREE.ShaderMaterial({ ...flat, uniforms: outU, fragmentShader: `
    uniform sampler2D tex, b0, b1, st; uniform float bloom, exposure, vig, aspect, contrast, sat, split, grain, seed, fade, dist, fringe, hal, streak, lift; uniform vec3 cool, warm, streakTint; varying vec2 vUv;
    float rnd(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233)) + seed * 0.37) * 43758.5453); }
    vec3 film(vec3 x) { return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0); }   // a filmic shoulder: bright things roll off instead of clipping
    void main() {
      vec2 p = vUv - 0.5, q = p * vec2(aspect, 1.0); float r2 = dot(q, q);
      vec2 uv = 0.5 + p * (1.0 + dist * r2) / (1.0 + dist * 0.3);                        // a lens bends straight lines a little
      vec2 off = p * fringe * (0.4 + 2.2 * r2);                                          // and the colours part slightly towards the edges
      vec3 c = vec3(texture2D(tex, uv + off).r, texture2D(tex, uv).g, texture2D(tex, uv - off).b);
      vec3 wide = texture2D(b1, uv).rgb;
      c += (texture2D(b0, uv).rgb * 0.6 + wide) * bloom;                                 // light bleeds from the bright things
      c += wide * hal * vec3(1.0, 0.32, 0.12);                                           // with a warm halo round them, as on film
      c += texture2D(st, uv).rgb * streak * streakTint;                                  // and a faint sideways streak, as through a squeezed lens
      c *= mix(1.0, smoothstep(0.95, 0.15, length(q) * 1.25), vig);
      c = pow(film(c * exposure), vec3(1.0 / 2.2));                                     // from light to what a screen shows; the grade below works on that
      c = mix(c, c * c * (3.0 - 2.0 * c), contrast);                                    // a firmer curve
      float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
      c = mix(vec3(l), c, sat);
      c += (cool - 0.5) * split * 0.10 * (1.0 - smoothstep(0.0, 0.45, l)) + (warm - 0.5) * split * 0.08 * smoothstep(0.45, 1.0, l);   // cool shadows, warm lights
      c = mix(vec3(lift), vec3(1.0), clamp(c, 0.0, 1.0));                                // blacks are never quite black
      c += (rnd(gl_FragCoord.xy) - 0.5) * grain * (1.0 - 0.5 * l);
      gl_FragColor = vec4(mix(c, vec3(0.0), fade), 1.0);
    }` });
  return {
    out: outU,
    render(n, each) {
      const auto = renderer.autoClear; renderer.autoClear = true; renderer.setRenderTarget(acc); renderer.setClearColor(0x000000, 1); renderer.clear(); addU.w.value = 1 / n;
      for (let i = 0; i < n; i++) { const [scene, camera] = each(i, n); renderer.setRenderTarget(frame); renderer.render(scene, camera); renderer.autoClear = false; addU.tex.value = frame.texture; pass(add, acc); renderer.autoClear = true; }
      brightU.tex.value = acc.texture; pass(bright, bA);
      for (const r of [1, 2]) { smear(bA, bB, r / bw, 0); smear(bB, bA, 0, r / bh); }
      const w2 = bw >> 1, h2 = bh >> 1; let from = bA;   // the wide glow: the blur grows in small steps, so no step leaves an edge round a bright thing
      for (const r of [1, 1.6, 2.4, 3.4]) { smear(from, cB, r / w2, 0); smear(cB, cA, 0, r / h2); from = cA; }
      smear(cA, sA, 5 / w2, 0); smear(sA, sB, 11 / w2, 0); smear(sB, sA, 23 / w2, 0); smear(sA, sB, 9 / w2, 0);   // the streak: the same light, smeared sideways only
      pass(out, null); renderer.autoClear = auto;
    },
  };
}

/** Puts it together: finish.render(t, drive) where drive(moment, frameTime) moves the scene and returns the camera's state. */
export function makeFinish(THREE, renderer, scene, W, H, look, parts, { fps = 30, subframes } = {}) {
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap; renderer.toneMapping = THREE.NoToneMapping;
  const L = look.lens || {}, N = subframes ?? L.subframes ?? 16, set = dress(THREE, renderer, scene, parts, look), P = makeLens(THREE, renderer, W, H, L);
  const cam = new THREE.PerspectiveCamera(35, W / H, 0.05, 200), right = new THREE.Vector3(), up = new THREE.Vector3(), fwd = new THREE.Vector3(), tmp = new THREE.Vector3(), tmp2 = new THREE.Vector3(), box = new THREE.Box3();
  const told = new Set(), focusPoint = (f, c, into) => { if (Array.isArray(f)) return into.set(f[0], f[1], f[2]); if (f && parts[f]) return box.setFromObject(parts[f]).getCenter(into);
    if (f && !told.has(f)) { told.add(f); console.warn(`look: a focus names a part that is not in the scene: "${f}" (have: ${Object.keys(parts).join(', ')}); the shot is focused on what its camera looks at`); } return into.copy(c.look); };
  return {
    subframes: N,
    render(t, drive, { duration = Infinity } = {}) {
      P.out.seed.value = Math.round(t * fps); P.out.fade.value = L.fadeOut ? Math.max(0, Math.min(1, (t - (duration - L.fadeOut)) / L.fadeOut)) : 0;
      // a whip pan is shot with the shutter wide open and drawn from twice the sub-frames: the cut disappears in the smear
      const whip = N > 1 && drive(t, t).whip, shutter = whip ? 1 : L.shutter ?? 0.5;
      P.render(whip ? N * 2 : N, (i, n) => {
        const moment = t + (n > 1 ? (halton(i + 1, 5) - 0.5) * shutter / fps : 0), c = drive(moment, t), [lx, ly] = n > 1 ? disc(i, n) : [0, 0];
        scene.updateMatrixWorld();                                                         // the scene has just moved: measure parts where they are now
        for (const f of set.follow) { set.centre(f.part, f.vec); if (f.offset) f.vec.add(f.offset); }
        for (const g of set.gated) g.light.visible = g.only ? g.only.includes(c.cam) : !g.not.includes(c.cam);
        for (const k of set.tied) k.light.intensity = k.base * (k.part.userData.glow ?? 1);
        for (const lamp of set.lamps) { const g = lamp.root.userData.glow ?? 1; lamp.mat.emissiveIntensity = lamp.power * g; lamp.light.intensity = lamp.strength * g;   // a scene may dim or flash a lamp: part.userData.glow
          if (lamp.sprite) { lamp.sprite.material.opacity = lamp.halo * Math.min(1.6, g); set.centre(lamp.root, lamp.at); lamp.sprite.position.copy(lamp.at).add(tmp.copy(c.pos).sub(lamp.at).setLength(lamp.radius * 1.15)); } }
        set.key.position.copy(set.keyBase).add(tmp.set(lx * set.soft, ly * set.soft, -lx * set.soft * 0.7));
        cam.fov = c.fov; cam.position.copy(c.pos); cam.lookAt(c.look); if (c.roll) cam.rotateZ(c.roll); cam.updateMatrixWorld(); cam.matrixWorld.extractBasis(right, up, fwd);
        const fp = focusPoint(c.focus, c, tmp); if (c.rack) fp.lerp(focusPoint(c.rack.to, c, tmp2), Math.max(0, Math.min(1.2, c.rack.k)));
        const dist = Math.max(0.02, fp.sub(c.pos).dot(tmp2.copy(c.look).sub(c.pos).normalize())) * (c.far ?? 1), ap = (c.aperture ?? L.aperture ?? 0.01) * (c.soft ?? 1);
        const fpx = (H / 2) / Math.tan(c.fov * Math.PI / 360), ox = lx * ap * (L.oval ?? 0.75), oy = ly * ap;   // a slightly squeezed opening: out-of-focus lights become upright ovals
        cam.position.addScaledVector(right, ox).addScaledVector(up, oy);
        cam.setViewOffset(W, H, -ox / dist * fpx + (n > 1 ? halton(i + 1, 2) - 0.5 : 0), oy / dist * fpx + (n > 1 ? halton(i + 1, 3) - 0.5 : 0), W, H); cam.updateProjectionMatrix();
        return [scene, cam];
      });
    },
  };
}
