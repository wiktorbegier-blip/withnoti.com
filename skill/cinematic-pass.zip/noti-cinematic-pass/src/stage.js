// The stage. Loads a scene (scenes/<name>.js) and draws any moment of it, in one of two ways:
//   raw       the animation as it is: its own materials, flat light, every camera locked where its shot puts it
//   finished  the same animation through the look (looks/<name>.js): paint, light, haze, lens and camera moves
// The page exposes window.renderAt(t), window.__dur and window.__ready for render.mjs, and window.__error when something is wrong.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { makeDirector, HOUSE_MOVES } from './camera.js';
import { makeFinish } from './finish.js';

const q = new URLSearchParams(location.search), W = +(q.get('w') || 1080), H = +(q.get('h') || 1920), FPS = 30, raw = q.get('raw') === '1';
const glc = document.getElementById('gl'), uic = document.getElementById('ui');
for (const c of [glc, uic]) { c.width = W; c.height = H; c.style.width = W + 'px'; c.style.height = H + 'px'; }
try {
  const def = (await import(`/scenes/${q.get('scene')}.js`)).default;
  const look = raw ? {} : (await import(`/looks/${q.get('look') || q.get('scene')}.js`)).default;
  const renderer = new THREE.WebGLRenderer({ canvas: glc, antialias: raw, preserveDrawingBuffer: true, powerPreference: 'high-performance' });
  renderer.setSize(W, H, false);
  const scene = new THREE.Scene();
  const built = await def.build({ THREE, scene, RoundedBoxGeometry });
  if (!built?.cameras || !built?.parts) throw new Error('the scene\'s build() must return { cameras, parts }');
  // `view` shows a share of the picture's height: a before-and-after draws each half at half height and usually wants less than all of it
  const view = +(q.get('view') || 1), cams = {};
  for (const [name, c] of Object.entries(built.cameras)) cams[name] = { ...c, fov: 2 * Math.atan(view * Math.tan((c.fov ?? 35) * Math.PI / 360)) * 180 / Math.PI };
  // the scene says which camera is on when; the look says how each of those shots moves and what it holds in focus
  const shots = (def.shots?.length ? def.shots : [{ t: 0, cam: Object.keys(cams)[0] }]).map((s, i) => ({ ...s, ...(raw ? {} : look.moves?.[i] ?? HOUSE_MOVES[i % HOUSE_MOVES.length]) }));
  // a focus that names no part would fall back to "whatever the camera looks at" without a word: say so now
  if (!raw) for (const s of shots) for (const f of new Set([s.focus, cams[s.cam]?.focus, s.rack?.to])) if (typeof f === 'string' && !built.parts[f]) console.warn(`look: the shot at ${s.t} s focuses on a part that is not in the scene: "${f}" (have: ${Object.keys(built.parts).join(', ')})`);
  const beats = def.beats || [], director = makeDirector(THREE, cams, shots, { duration: def.duration, raw, beats, aspect: W / H, punch: look.punch ?? 1 });
  let renderAt;
  if (raw) {
    let lit = false; scene.traverse((o) => { if (o.isLight) lit = true; });
    if (!lit) { scene.add(new THREE.HemisphereLight(0xffffff, 0x8c8c8c, 2.2)); const sun = new THREE.DirectionalLight(0xffffff, 1.1); sun.position.set(-2, 4, 3); scene.add(sun); }
    if (!scene.background) scene.background = new THREE.Color(0x4b4b4b);
    const cam = new THREE.PerspectiveCamera(35, W / H, 0.05, 200);
    renderAt = (t) => { def.update?.(t); const c = director.at(t); cam.fov = c.fov; cam.position.copy(c.pos); cam.lookAt(c.look); cam.updateProjectionMatrix(); renderer.render(scene, cam); };
  } else {
    def.update?.(0);   // the look measures parts (to aim a light at 'head'): put everything in its first pose before it does
    const finish = makeFinish(THREE, renderer, scene, W, H, look, built.parts, { fps: FPS, subframes: q.get('n') ? +q.get('n') : undefined });
    renderAt = (t) => finish.render(t, (moment, frame) => { def.update?.(moment); return director.at(moment, frame); }, { duration: def.duration });
  }
  // a label in the corner, for the two halves of a before-and-after
  const label = q.get('label');
  if (label) { const x = uic.getContext('2d'), s = W / 1080, pad = 22 * s; x.font = `700 ${38 * s}px ui-monospace, Menlo, Consolas, monospace`; const w = x.measureText(label).width + pad * 2 + 3 * s * label.length, h = 64 * s;
    x.fillStyle = q.get('tone') === 'warm' ? '#f0883e' : 'rgba(16,14,12,0.82)'; x.beginPath(); x.roundRect(40 * s, 40 * s, w, h, 14 * s); x.fill();
    x.fillStyle = q.get('tone') === 'warm' ? '#1c1007' : '#f4ede4'; x.textBaseline = 'middle'; x.letterSpacing = `${3 * s}px`; x.fillText(label, 40 * s + pad, 40 * s + h / 2 + 2 * s); }
  window.renderAt = renderAt; window.__dur = def.duration; window.__shots = shots.map((s) => ({ t: s.t, cam: s.cam })); window.__ready = true;
} catch (err) {
  window.__error = String(err?.message || err);
}
