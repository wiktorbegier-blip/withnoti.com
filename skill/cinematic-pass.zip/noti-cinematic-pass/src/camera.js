// The camera. A shot list goes in; for any moment, where the camera is, what it looks at and its lens come out.
//
// A shot:   { t, cam }                       from second t, the camera named `cam`
// A move:   push 0.06     towards the subject, as a share of the distance (negative pulls back)
//           arc 6         degrees round the subject, half before the middle of the shot and half after
//           truck 0.015   sideways, as a share of the distance       crane 0.015   up, as a share of the distance
//           hand 1        hand-held strength (0 is a tripod that only breathes)
//           vertigo 0.2   moves in while the lens widens: the subject holds its size and the room stretches behind it
//           rack { to: 'part', at: 1.2 }   pulls focus to another part, 1.2 s into the shot
//           in 'snap'     lands a touch tight and settles     in 'crash'    the lens slams in and settles
//           in 'defocus'  arrives soft and finds focus (a good first shot)
//           in 'whip'     a fast pan smears the cut ('whip-left' for the other way)
// One or two moves per shot. A raw render ignores every move: the camera sits where the shot puts it.
//
// A shot the look gives no move to gets one of the house's quiet ones, in turn, so no two neighbours move alike.
// Every amount is a share of the distance between the camera and what it looks at (or an angle), never metres: the same
// look moves a table-top shot and a room alike.
export const HOUSE_MOVES = [{ push: 0.045 }, { arc: 5, push: 0.02 }, { truck: 0.012, push: 0.02 }, { push: 0.06 }, { arc: -5, push: 0.02 }, { crane: 0.013, push: 0.03 }];

const clamp01 = (x) => Math.max(0, Math.min(1, x));
const smooth = (x) => { x = clamp01(x); return x * x * (3 - 2 * x); };
// a value that goes from 0 to 1 and overshoots a little on the way, like a hand settling: f swings a second, z how fast they die
export const settle = (t, f, z) => { if (t <= 0) return 0; z = Math.min(z, 0.98); const w = 2 * Math.PI * f, wd = w * Math.sqrt(1 - z * z); return 1 - Math.exp(-z * w * t) * (Math.cos(wd * t) + (z * w / wd) * Math.sin(wd * t)); };
const whipDir = (s) => (s && typeof s.in === 'string' && s.in.startsWith('whip') ? (s.in === 'whip-left' ? -1 : 1) : 0);
const hash = (n) => { const s = Math.sin(n * 127.1) * 43758.5453; return s - Math.floor(s); };
// smooth wandering between -1 and 1; `seed` picks a different wander
export const drift = (x, seed = 0) => { const i = Math.floor(x), f = x - i, u = f * f * (3 - 2 * f); return (hash(i + seed * 57.3) * (1 - u) + hash(i + 1 + seed * 57.3) * u) * 2 - 1; };

export function makeDirector(THREE, cams, shotList, { duration, raw = false, beats = [], aspect = 9 / 16, punch = 1 } = {}) {
  const shots = shotList.slice().sort((a, b) => a.t - b.t);
  // a camera's pos and look are points, or functions of the second (a camera that travels in the animation itself: that is the scene's, so the raw render has it too)
  const V = (a, t) => { const v = typeof a === 'function' ? a(t) : a; return new THREE.Vector3(v[0], v[1], v[2]); }, Y = new THREE.Vector3(0, 1, 0), fwd = new THREE.Vector3(), side = new THREE.Vector3();
  for (const s of shots) if (!cams[s.cam]) throw new Error(`shot at ${s.t} s names a camera that does not exist: "${s.cam}" (have: ${Object.keys(cams).join(', ')})`);

  /** t is the moment being drawn; T is the frame it belongs to, which decides the shot (so a cut is never blurred across). */
  function at(t, T = t) {
    let k = 0; for (let i = 0; i < shots.length; i++) if (shots[i].t <= T + 1e-6) k = i;
    const s = shots[k], end = shots[k + 1] ? shots[k + 1].t : duration, c = cams[s.cam];
    t = Math.max(s.t, Math.min(end, t));
    const e = smooth((t - s.t) / Math.max(0.001, end - s.t)), since = t - s.t;
    const pos = V(c.pos, t), look = V(c.look, t); let fov = c.fov ?? 35, roll = 0, soft = 1, far = 1, rack = null, whip = false;
    if (!raw) {
      const reach = pos.distanceTo(look), m = reach / 3;   // the hand's tremor and a punch's shake were tuned three metres from the subject; closer, they shrink with the distance
      if (s.arc) pos.sub(look).applyAxisAngle(Y, s.arc * Math.PI / 180 * (e - 0.5)).add(look);
      if (s.truck || s.crane) { fwd.copy(look).sub(pos).normalize(); side.crossVectors(fwd, Y).normalize(); const dx = (s.truck || 0) * reach * (e - 0.5); pos.addScaledVector(side, dx); look.addScaledVector(side, dx * 0.6); pos.y += (s.crane || 0) * reach * (e - 0.5); }
      if (s.vertigo) { const d0 = pos.distanceTo(look); pos.lerp(look, s.vertigo * e); fov = 2 * Math.atan(Math.tan(fov * Math.PI / 360) * d0 / pos.distanceTo(look)) * 180 / Math.PI; }
      if (s.push) pos.lerp(look, s.push * e);
      if (s.in === 'crash') fov *= 1 + 0.6 * (1 - settle(since, 3.4, 0.5));
      if (s.in === 'snap') fov *= 1 - 0.07 * (1 - settle(since, 4.2, 0.45));
      if (s.in === 'defocus') { const k = 1 - settle(since, 1.5, 0.95); far = 1 + 1.3 * k; soft = 1 + 1.6 * k; }      // the lens is focused too far and wide open, then comes in
      if (s.rack) rack = { to: s.rack.to, k: settle(since - (s.rack.at ?? 0), 1.6, 0.8) };
      // a whip: the camera swings out of one shot and into the next, and the shutter stays open across the cut
      // (it swings about a frame and a half: far enough to lose the picture in the blur, not so far that it shows an empty wall)
      const wi = whipDir(s), wo = whipDir(shots[k + 1]), swing = 2.8 * Math.atan(Math.tan(fov * Math.PI / 360) * aspect); let yaw = 0;
      if (wi && since < 0.22) yaw -= wi * swing * (1 - since / 0.22) ** 3;
      if (wo && t > end - 0.13) yaw += wo * swing * ((t - (end - 0.13)) / 0.13) ** 2;
      if (yaw) look.sub(pos).applyAxisAngle(Y, -yaw).add(pos);
      whip = (wi && since < 0.22) || (wo && t > end - 0.14);
      // a held camera is never perfectly still; a hand-held one moves more and faster
      const h = s.hand || 0, seed = k * 3.1;
      pos.x += (drift(t * 0.35, 1 + seed) * 0.006 + drift(t * 1.7, 11 + seed) * 0.004 * h) * m; pos.y += (drift(t * 0.3, 2 + seed) * 0.005 + drift(t * 2.1, 12 + seed) * 0.004 * h) * m;
      look.x += (drift(t * 0.27, 3 + seed) * 0.006 + drift(t * 1.9, 13 + seed) * 0.006 * h) * m; look.y += (drift(t * 0.31, 4 + seed) * 0.005 + drift(t * 2.3, 14 + seed) * 0.006 * h) * m;
      roll += drift(t * 0.9, 15 + seed) * 0.006 * h;
      // a beat marked `punch` gives the lens a quick push and the camera a short shake
      // (the look can turn every punch up or down with one number, punch: 0.5, without touching the scene)
      for (const b of beats) { const u = t - b.t; if (!b.punch || !punch || u < 0 || u > 1.2) continue; const a = (b.punch === true ? 1 : b.punch) * punch;
        fov *= 1 - 0.07 * a * (settle(u, 5, 0.35) - settle(u - 0.08, 2.2, 0.8)); const sh = a * Math.exp(-u / 0.12) * m;
        pos.x += drift(t * 41, 21) * 0.01 * sh; pos.y += drift(t * 37, 22) * 0.01 * sh; look.x += drift(t * 33, 23) * 0.014 * sh; look.y += drift(t * 39, 24) * 0.014 * sh; }
    }
    return { pos, look, fov, roll, shot: k, cam: s.cam, focus: s.focus ?? c.focus ?? null, aperture: s.aperture ?? c.aperture ?? null, soft, far, rack, whip };
  }
  return { at, shots };
}
