#!/usr/bin/env node
// Draws a scene (scenes/<name>.js) raw or through its look (looks/<name>.js), by opening the stage in a headless browser.
//
//   node render.mjs <scene> compare [5]      one moment from each shot (six at most, from shot 5 on if you say so), raw above and finished below   -> out/<scene>/compare.jpg
//   node render.mjs <scene> sheet [raw]      eight frames side by side (finished, or raw)      -> out/<scene>/sheet.jpg | sheet-raw.jpg
//   node render.mjs <scene> stills 1.2,3.4 [raw]   single full-size frames at those seconds   -> out/<scene>/stills/
//   node render.mjs <scene> strip 4.4 [raw]  eight frames in a row from that second: what a move, a cut or a flicker really does  -> out/<scene>/strip.jpg
//   node render.mjs <scene> draft            half-size finished video, quick                   -> out/<scene>/<scene>-draft.mp4
//   node render.mjs <scene> video            full-size finished video, 1080 x 1920, 30 fps     -> out/<scene>/<scene>.mp4
//   node render.mjs <scene> raw              full-size raw video                               -> out/<scene>/<scene>-raw.mp4
//   node render.mjs <scene> split [draft]    before above, after below, in one video           -> out/<scene>/<scene>-split.mp4 | -split-draft.mp4
//                                            (each half is half the height of the frame. --view says how much of the picture's height it shows:
//                                             0.5 is exactly the film's width and the middle half of its height; 1 is all of the height and
//                                             twice the film's width, so more of the set at the sides; 0.72, the default, sits between)
//
// With --look <name> the pictures (compare, sheet, strip, stills) carry the look's name, so two looks can be laid side by side.
//
//   options:  --look <name>    use looks/<name>.js instead of the look named after the scene
//             --n <number>     sub-frames per frame for this run (the look's own number otherwise; 4 for a draft)
//             --audio <file>   lay this sound file under a draft, a video or a split
//             --view <0..1>    for split: how much of the frame's height each half shows (default 0.72)
//
// Every run replaces the file that command wrote before. While it runs it serves this folder to its own browser on
// 127.0.0.1 (this computer only). Needs Node 20 or newer, ffmpeg on the PATH and Google Chrome (or CHROME_PATH).
import { createServer } from 'node:http';
import { readFile, mkdir } from 'node:fs/promises';
import { existsSync, rmSync } from 'node:fs';
import { spawn, spawnSync } from 'node:child_process';
import { dirname, extname, join, normalize, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = dirname(fileURLToPath(import.meta.url)), FPS = 30, W = 1080, H = 1920;
const args = process.argv.slice(2), opt = (name) => { const i = args.indexOf(name); if (i < 0) return null; const v = args[i + 1]; args.splice(i, 2); return v; };
const lookName = opt('--look'), nOpt = opt('--n'), audio = opt('--audio'), view = Number(opt('--view') || 0.72);
const [name, mode = 'compare', extra, extra2] = args;
const fail = (message) => { console.error(message); process.exit(2); };
if (!name || !/^[\w-]+$/.test(name)) fail('usage: node render.mjs <scene> compare [first shot] | sheet [raw] | stills t1,t2 [raw] | strip t [raw] | draft | video | raw | split [draft]   [--look name] [--n subframes] [--audio file] [--view 0..1]');
if (!existsSync(join(ROOT, 'scenes', `${name}.js`))) fail(`No scene at scenes/${name}.js`);
const look = lookName || name;
const needsLook = !(mode === 'raw' || extra === 'raw' || extra2 === 'raw');
if (needsLook && !existsSync(join(ROOT, 'looks', `${look}.js`))) fail(`No look at looks/${look}.js. Copy looks/sample.js to looks/${look}.js and change it, or render raw first: node render.mjs ${name} sheet raw`);
if (spawnSync('ffmpeg', ['-version']).status !== 0) fail('ffmpeg was not found. Install it (macOS: brew install ffmpeg; Windows: winget install ffmpeg; Linux: your package manager), then run this again.');
if (!existsSync(join(ROOT, 'node_modules', 'three'))) fail('Run "npm install" in this folder first.');
if (audio && !existsSync(audio)) fail(`No sound file at ${audio}`);
const OUT = join(ROOT, 'out', name), tag = lookName && lookName !== name ? `-${lookName}` : '';
await mkdir(OUT, { recursive: true });

// ---- a small file server for the browser, this folder only
const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.json': 'application/json', '.jpg': 'image/jpeg', '.png': 'image/png' };
const server = createServer(async (req, res) => {
  try {
    const file = normalize(join(ROOT, decodeURIComponent(req.url.split('?')[0])));
    if (!file.startsWith(ROOT + sep)) throw new Error('outside');
    res.setHeader('content-type', TYPES[extname(file)] || 'application/octet-stream'); res.setHeader('cache-control', 'no-store'); res.end(await readFile(file));
  } catch { res.statusCode = 404; res.end(); }
}).listen(0, '127.0.0.1');
await new Promise((resolve) => server.once('listening', resolve));

// ---- the browser
const { chromium } = await import('playwright-core');
const chrome = process.env.CHROME_PATH || ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', 'C:/Program Files/Google/Chrome/Application/chrome.exe', 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe', '/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium', '/usr/bin/chromium-browser'].find((p) => existsSync(p));
let browser;
try {
  browser = await chromium.launch({ ...(chrome ? { executablePath: chrome } : {}), headless: true, args: ['--enable-gpu', '--ignore-gpu-blocklist', '--enable-unsafe-swiftshader', ...(process.platform === 'darwin' ? ['--use-angle=metal'] : [])] });
} catch (err) {
  server.close(); fail(`No browser could be started (${String(err.message).split('\n')[0]}).\nInstall Google Chrome, or set CHROME_PATH to a Chrome or Chromium program, or run: npx playwright-core install chromium`);
}
const done = async (code = 0) => { await Promise.race([browser.close(), new Promise((r) => setTimeout(r, 8000))]); server.close(); process.exit(code); };

/** Open the stage for one way of drawing the scene. Returns the page and the scene's length. */
async function open({ raw = false, w = W, h = H, n = null, label = '', tone = '', share = 1 } = {}) {
  const page = await browser.newPage({ viewport: { width: w, height: h } });
  const said = [];
  page.on('pageerror', (e) => said.push(e.message)); page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') said.push(m.text()); });
  const params = new URLSearchParams({ scene: name, look, w, h, ...(raw ? { raw: 1 } : {}), ...(n ? { n } : {}), ...(label ? { label, tone } : {}), ...(share !== 1 ? { view: share } : {}) });
  await page.goto(`http://127.0.0.1:${server.address().port}/src/stage.html?${params}`);
  await page.waitForFunction('window.__ready === true || window.__error', null, { timeout: 120000 }).catch(() => {});
  const error = await page.evaluate(() => window.__error || (window.__ready ? '' : 'the stage did not start'));
  if (error) { console.error(`The ${raw ? 'scene' : 'scene or its look'} could not be drawn: ${error}`); for (const line of said.slice(0, 6)) console.error('  ' + line); await done(1); }
  for (const line of said.filter((s) => s.startsWith('look:'))) console.warn(line);
  return { page, dur: await page.evaluate(() => window.__dur), shots: await page.evaluate(() => window.__shots) };
}
const frame = async (page, t) => { await page.evaluate((x) => window.renderAt(x), t); return page.screenshot({ type: 'jpeg', quality: 93 }); };
const ffmpeg = (argv, feed) => new Promise((resolve, reject) => {
  const p = spawn('ffmpeg', ['-y', '-loglevel', 'error', ...argv], { stdio: [feed ? 'pipe' : 'ignore', 'inherit', 'inherit'] });
  p.once('close', (code) => (code === 0 ? resolve() : reject(new Error('ffmpeg stopped with an error (see above)'))));
  if (feed) feed(p.stdin).then(() => p.stdin.end(), reject);
});
const write = (stream, buf) => (stream.write(buf) ? Promise.resolve() : new Promise((r) => stream.once('drain', r)));
/** Lay pictures out in a grid and save them as one image. */
const tile = (buffers, cols, rows, file, scaleW) => ffmpeg(['-f', 'image2pipe', '-framerate', '1', '-c:v', 'mjpeg', '-i', '-', '-vf', `scale=${scaleW}:-2,tile=${cols}x${rows}`, '-frames:v', '1', '-q:v', '3', file], async (stdin) => { for (const b of buffers) await write(stdin, b); });
/** Film a page from start to end into a video file. */
async function film(page, dur, file, { audio: sound } = {}) {
  const total = Math.round(dur * FPS), t0 = Date.now(), silent = sound ? file.replace(/\.mp4$/, '-silent.mp4') : file;
  await ffmpeg(['-f', 'image2pipe', '-framerate', String(FPS), '-c:v', 'mjpeg', '-i', '-', '-vf', 'scale=out_color_matrix=bt709:out_range=tv,format=yuv420p', '-c:v', 'libx264', '-preset', 'medium', '-crf', '16', '-movflags', '+faststart', silent],
    async (stdin) => { for (let f = 0; f < total; f++) { await write(stdin, await frame(page, f / FPS)); if (f % 30 === 29) process.stdout.write(`\r  ${f + 1} of ${total} frames`); } });
  process.stdout.write(`\r  ${total} frames in ${((Date.now() - t0) / 1000).toFixed(0)} s      \n`);
  if (sound) { await ffmpeg(['-i', silent, '-i', sound, '-map', '0:v', '-map', '1:a', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart', file]); rmSync(silent, { force: true }); }
}
const spread = (dur, n) => Array.from({ length: n }, (_, i) => +(((i + 0.5) * dur) / n).toFixed(2));

try {
  if (mode === 'compare') {
    // one moment from each shot (six at a time), so every camera is judged; raw above, finished below
    const a = await open({ raw: true, w: W / 2, h: H / 2 }), b = await open({ w: W / 2, h: H / 2, n: nOpt || 8 });
    const cuts = a.shots.map((s, i) => [s.t, a.shots[i + 1]?.t ?? a.dur]), first = Math.max(1, Math.min(cuts.length, Number(extra) || 1)), shown = cuts.slice(first - 1, first + 5);
    const picks = shown.map(([s, e]) => +(s + (e - s) * 0.6).toFixed(2)), times = cuts.length >= 2 ? picks : spread(a.dur, 4), shotsA = [], shotsB = [];
    for (const t of times) { shotsA.push(await frame(a.page, t)); shotsB.push(await frame(b.page, t)); }
    await tile([...shotsA, ...shotsB], times.length, 2, join(OUT, `compare${tag}.jpg`), W / 2);
    console.log(`out/${name}/compare${tag}.jpg   (raw above, finished below; at ${times.join(', ')} s)`);
    if (cuts.length > first + 5) console.log(`  Shots ${first} to ${first + 5} of ${cuts.length}. The rest: node render.mjs ${name} compare ${first + 6}`);
  } else if (mode === 'sheet') {
    const raw = extra === 'raw', s = await open({ raw, w: W / 2, h: H / 2, n: nOpt || 8 }), times = spread(s.dur, 8), shots = [];
    for (const t of times) shots.push(await frame(s.page, t));
    const file = raw ? 'sheet-raw.jpg' : `sheet${tag}.jpg`; await tile(shots, 8, 1, join(OUT, file), W / 4);
    console.log(`out/${name}/${file}   (at ${times.join(', ')} s)`);
  } else if (mode === 'strip') {
    // eight frames in a row: the only way to see, without watching, what a move, a cut or a flicker does from one frame to the next
    if (!extra || !/^[\d.]+$/.test(extra)) fail('strip needs the second it starts at: node render.mjs <scene> strip 4.4');
    const raw = extra2 === 'raw', s = await open({ raw, w: W / 2, h: H / 2, n: nOpt }), t0 = Math.max(0, Math.min(Number(extra), s.dur - 8 / FPS)), shots = [];
    for (let i = 0; i < 8; i++) shots.push(await frame(s.page, Math.round(t0 * FPS + i) / FPS));
    const file = raw ? 'strip-raw.jpg' : `strip${tag}.jpg`; await tile(shots, 8, 1, join(OUT, file), W / 4);
    console.log(`out/${name}/${file}   (frames ${Math.round(t0 * FPS)} to ${Math.round(t0 * FPS) + 7}, from ${t0.toFixed(2)} s)`);
  } else if (mode === 'stills') {
    if (!extra || !/^[\d.,]+$/.test(extra)) fail('stills needs the seconds: node render.mjs <scene> stills 1.2,3.4');
    const raw = extra2 === 'raw', s = await open({ raw, n: nOpt }); await mkdir(join(OUT, 'stills'), { recursive: true });
    const { writeFile } = await import('node:fs/promises');
    for (const t of extra.split(',').map(Number)) { const file = `stills/${name}${raw ? '-raw' : tag}_${t.toFixed(2).padStart(6, '0')}.jpg`; await writeFile(join(OUT, file), await frame(s.page, Math.min(t, s.dur))); console.log(`out/${name}/${file}`); }
  } else if (mode === 'draft' || mode === 'video' || mode === 'raw') {
    const draft = mode === 'draft', raw = mode === 'raw', s = await open({ raw, w: draft ? W / 2 : W, h: draft ? H / 2 : H, n: nOpt || (draft ? 4 : null) });
    const file = join(OUT, `${name}${draft ? '-draft' : raw ? '-raw' : ''}.mp4`); await film(s.page, s.dur, file, { audio });
    console.log(`out/${name}/${file.split(sep).pop()}`);
  } else if (mode === 'split') {
    const draft = extra === 'draft', w = draft ? W / 2 : W, h = draft ? H / 4 : H / 2;
    const a = await open({ raw: true, w, h, label: 'BEFORE', share: view }); await film(a.page, a.dur, join(OUT, 'split-before.mp4')); await a.page.close();
    const b = await open({ w, h, n: nOpt || (draft ? 4 : null), label: 'AFTER', tone: 'warm', share: view }); await film(b.page, b.dur, join(OUT, 'split-after.mp4'));
    const file = join(OUT, `${name}-split${draft ? '-draft' : ''}.mp4`);
    await ffmpeg(['-i', join(OUT, 'split-before.mp4'), '-i', join(OUT, 'split-after.mp4'), ...(audio ? ['-i', audio] : []), '-filter_complex', '[0:v][1:v]vstack=inputs=2,format=yuv420p[v]', '-map', '[v]', ...(audio ? ['-map', '2:a', '-c:a', 'aac', '-b:a', '192k', '-shortest'] : ['-an']), '-c:v', 'libx264', '-preset', 'medium', '-crf', '17', '-movflags', '+faststart', file]);
    rmSync(join(OUT, 'split-before.mp4'), { force: true }); rmSync(join(OUT, 'split-after.mp4'), { force: true });
    console.log(`out/${name}/${file.split(sep).pop()}   (before above, after below; --view ${view}: each half shows ${view} of the picture's height and ${(view * 2).toFixed(2)} times the film's width)`);
  } else fail(`Unknown command "${mode}". Run "node render.mjs" for the list.`);
  await done(0);
} catch (err) {
  console.error(err.message); await done(1);
}
