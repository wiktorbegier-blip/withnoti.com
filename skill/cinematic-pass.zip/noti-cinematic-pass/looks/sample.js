// The look for the sample scene. A look is everything the pass adds to an animation; the scene file is not touched.
// This one starts from the house look (src/house.js: the palette, light balance and lens our own films use) and adds
// what only this scene can know: what each part is, where the lights stand, how each shot moves, which sound goes where.
//
//   palette   three or four colours the whole film is made of. Name them; use the names everywhere else.
//   paint     per part: { color, rough } or, for something that gives light, { glow, power, light, reach, lightAt, halo, haloSize }.
//             A part inside another part keeps its own paint (a head inside a person stays a head).
//             (metal: 0 to 1 exists too, but a metal only shows what it reflects: use it with `reflect` in a room that has light in it.)
//   rest      the colour of anything the paint list does not name
//   key       the main light: where from, what it aims at (a part's name or a point), colour, power, angle (how wide, in radians), soft (how soft its shadows are)
//   rim       a light from behind the subject, on the far side from the key: it draws the outline
//   lights    any more, each with a job: { kind: 'point' | 'spot', from, at, color, power, reach }
//             any light may add  only: ['camera'] / not: ['camera']  (on for some cameras only)  and  with: 'part'  (dims and flashes with that lamp)
//   fill, sky, ground   the little light there is in the shadows
//   air, haze, reflect  the colour of the dark, how fast things fade into it, how much of the room shows in glossy surfaces
//   lens      subframes, shutter, aperture, oval, bloom, halation, streak, fringe, distortion, vignette, grain, contrast, saturation, split, lift
//   moves     one entry per shot, in the scene's order: how the camera moves and what it holds in focus (see src/camera.js)
//   punch     how hard the camera reacts to the scene's punched beats (1 as the scene wrote them, 0 not at all)
//   sound     which sound goes with which kind of moment (see sound.mjs)
import { houseLook } from '../src/house.js';

export default houseLook('dusk', {
  paint: {
    floor: { color: '#241a14', rough: 0.5 }, wall: { color: '#2a231f', rough: 0.95 },                       // neutral and dark: the lamp colours them
    desk: { color: 'wood', rough: 0.38 }, chair: { color: '#191310', rough: 0.6 },
    monitor: { color: '#141110', rough: 0.3 }, keyboard: { color: '#26221f', rough: 0.5 }, mug: { color: '#e6dccb', rough: 0.35 },
    person: { color: '#7f756a', rough: 0.85 }, legs: { color: '#1b1826', rough: 0.9 },
    head: { color: '#e9a482', rough: 0.65 }, hair: { color: '#2a1810', rough: 0.85 }, eyes: { color: '#120a0c', rough: 0.4 },
    lamp: { color: '#1a1512', rough: 0.5 }, shelf: { color: 'wood', rough: 0.55 }, books: { color: '#b8552c', rough: 0.8 },
    shade: { glow: 'warm', power: 2.4, light: 8, reach: 8, halo: 0.4, haloSize: 1.3 },                      // the lamp: the reason the room is warm
    screen: { glow: '#aab9ff', power: 0.55, light: 2.2, reach: 3, lightAt: [0, 0, 0.3], halo: 0 },          // the screen: a second, cooler source on the face
  },
  key: { from: [-2.4, 2.4, -1.2], at: 'head', power: 40 },                    // to one side of every camera that sees the face, and above; it stays on the head as they move
  rim: { from: [1.5, 2.5, 2.6], at: 'head', power: 120, not: ['over'] },      // behind them, on the other side: the indigo edge on hair and shoulder
  lights: [
    { kind: 'spot', from: [-1.7, 2.3, -2.1], at: 'head', color: 'cool', power: 90, only: ['over'] },   // the camera behind them gets its own rim, from beyond them
    { kind: 'point', from: [1.6, 0.5, 1.9], color: 'amber', power: 1.6, reach: 6 },                    // a low amber bounce, so the far corner is dark but not empty
  ],
  moves: [
    { in: 'defocus', push: 0.1, aperture: 0.007 },                          // wide: the film finds focus, then closes in on the room
    { arc: 7, push: 0.06, focus: 'hair', rack: { to: 'screen', at: 0.3 } }, // over the shoulder: focus leaves them for the screen as it lights
    { in: 'snap', push: 0.06, hand: 1 },                                    // close: lands on the face, a little unsteady, and keeps coming
  ],
  sound: { cut: 'whoosh', snap: 'tick', screen: 'blip', move: 'cloth', bed: 'room', music: 'music' },
});
