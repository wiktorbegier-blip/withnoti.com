Your sound files go here (wav, mp3, m4a, aiff, flac or ogg).

Name them as the look's `sound` list names them: with `sound: { cut: 'whoosh', screen: 'blip', bed: 'room' }`
the mixer looks for sounds/whoosh.*, sounds/blip.* and sounds/room.*.

`node sound.mjs <scene> plan` lists which kinds a scene needs. No sound comes with the kit: use files you have the right to use.
