# The cinematic pass

Turns a plain 3D animation made in code into something that looks like a film: colour and materials, a key and a rim light, lamps that light the room, haze, a squeezed lens with depth of field and motion blur, camera moves, and a map of where every sound goes. It never changes the animation itself, so it can show you the two side by side: before above, after below.

It starts from our house look, the one we finish our own films with: a warm room with one cool line. The numbers are in `src/house.js`, and the rules behind them are in `SKILL.md`. Keep it, or keep its structure and put your own colours in.

It is also a **skill for Claude Code**: put this folder where Claude Code looks for skills, give it an animation (or use the sample), and ask it to make it cinematic. Claude writes the look, checks the frames and renders the before and after.

From NōTI.

## What you need

- [Node.js](https://nodejs.org) 20 or newer
- [ffmpeg](https://ffmpeg.org) (macOS: `brew install ffmpeg`; Windows: `winget install ffmpeg`; Linux: your package manager)
- Google Chrome

## Try it

```
cd noti-cinematic-pass
npm install
node render.mjs sample compare
```

That writes `out/sample/compare.jpg`: the sample scene raw above, finished below.

| Command | What you get |
|---|---|
| `node render.mjs sample compare` | one moment from each shot, raw above and finished below |
| `node render.mjs sample sheet` | eight finished frames side by side (`sheet raw` for the raw ones) |
| `node render.mjs sample draft` | a quick half-size finished video |
| `node render.mjs sample split` | the before and after as one video |
| `node render.mjs sample video` | the finished video, 1080 x 1920 |
| `node sound.mjs sample plan` | where each sound goes |

## Your own animation

An animation is a file in `scenes/` (what there is, how it moves, which camera when). Its finish is a file with the same name in `looks/` (paint, light, lens, camera moves, sounds). Copy `scenes/sample.js` and `looks/sample.js`, rename both, and change them; the comments at the top of each say what every line does. The scene is never changed by the pass: everything it adds is in the look.

A look starts from the house look and adds what only your scene knows: what each part is, where the lights stand, how each shot moves. `houseLook('dusk', { ... })` is the look as we use it; `houseLook('night', { ... })` is the same room later, with the lamps carrying everything. Your own colours: `houseLook('dusk', { palette: { warm: '#ffd27a', cool: '#19c3b1' } })`.

## Use it with Claude Code

Put this folder in one of the two places Claude Code reads skills from:

- for every project: `~/.claude/skills/noti-cinematic-pass/`
- for one project: `<your project>/.claude/skills/noti-cinematic-pass/`

Then ask, in plain words: "make my animation cinematic", "light this scene", "show me a before and after". `SKILL.md` is what Claude follows.

## Sound

No sound files are included. Put your own in `sounds/`; `node sound.mjs <scene> plan` tells you which kinds are needed and where each one goes. Use sounds you have the right to use. `node sound.mjs <scene> mix` mixes them: a sound that comes back is varied so it is not heard as a repeat, the music takes a breath before the key moment, and the result is set to the loudness phones expect.

## What it does not do

It does not write a story, build a scene or animate anything: it finishes an animation you already have. It has no voices and no music of its own.

## Licence

Free for personal use: your own projects, your own channel. Not for client or company work, and not to be sold or passed on; for that, write to contact@withnoti.com. The full text is in `LICENSE`.
