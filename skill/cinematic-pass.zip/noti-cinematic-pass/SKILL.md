---
name: cinematic-pass
description: Give a 3D animation made in code the look of a film - colour and materials, a key and a rim light, lamps that really light the room, haze, an anamorphic lens with depth of field and motion blur, camera moves, and a sound map - and show it as a before and after. Starts from NōTI's own house look (a warm room with one cool line) or from the user's colours. Use this whenever the user asks to make an animation, a three.js scene, a render or a reel look cinematic, professional, less flat or less grey; asks for lighting, a colour palette, camera movement, a lens look, or sound effects for an animation; asks for a before and after of a scene; or has a grey blockout that needs finishing. It works on an animation that already exists (or the sample scene in this folder); it does not write a story or build a scene from nothing.
---

# The cinematic pass

A plain animation goes in: grey shapes, flat light, a camera that just looks. The same animation comes out as a film frame: painted, lit, shot through a lens, with a camera that moves for a reason and a list of where every sound goes. **The animation itself is never changed.** What moves, when, and which camera is on stay exactly as they were. Everything the pass adds lives in one small file, a **look**.

This folder is the tool: a stage that draws a scene raw or finished, a renderer, and a sound mixer. All commands run from **this skill's folder** (the one this file is in).

| File | What it is |
|---|---|
| `scenes/<name>.js` | The animation: objects, how they move, which camera when. `scenes/sample.js` is the worked example |
| `looks/<name>.js` | The pass for that scene: paint, light, lens, camera moves, sounds. `looks/sample.js` is the worked example |
| `src/house.js` | The house look: the palette, light balance and lens NōTI's own films use, as a starting point for any look |
| `render.mjs` | Draws stills, sheets, drafts, finals and the before-and-after |
| `sound.mjs` | Works out the sound map and mixes the user's own sound files |
| `src/` | The stage, the camera and the finish. Read `src/camera.js` for the moves; you rarely need to change anything here |

## Before the first render

1. `node_modules/` missing? Run `npm install` (two packages: three and playwright-core).
2. `ffmpeg -version` must work. If not, tell the user how to install it (macOS `brew install ffmpeg`, Windows `winget install ffmpeg`, Linux their package manager) and stop.
3. Google Chrome is found by itself. Without it: set `CHROME_PATH`, or run `npx playwright-core install chromium`.
4. `node render.mjs sample compare` should write `out/sample/compare.jpg`: the sample raw above, finished below. Open it. If it is there, everything works, and you have seen what the pass does.

## The loop

Work in this order. Each step is judged on a picture before the next one starts; never tune three things at once.

1. **Put the animation on the stage** (a scene file) and look at it raw: `node render.mjs <name> sheet raw`.
2. **Start the look from the house look** and **paint**: a colour for every part. Check with `compare`. (The house lights are already on, from front left and behind right, so paint is judged under light; you place them properly in the next step.)
3. **Light** it: where the key and rim stand, lamps, haze. Check with `compare`.
4. **Lens**: focus and aperture per shot. Check with `stills` at full size.
5. **Camera**: give each shot one move with a reason. Check with `sheet`, then a `draft`.
6. **Sound**: `node sound.mjs <name> plan`, files from the user, `mix`.
7. **Deliver**: `node render.mjs <name> split` (the before and after) and `node render.mjs <name> video`.

`compare` is the command you will use most: one moment from each shot, raw above and finished below (six shots at a time; `compare 7` shows the next six). Open the image and actually look at it after every change (see "What to look for"). With `--look other` the picture is named after that look, so two looks can be compared.

**Scale. Every number in this file assumes a person-size subject with the lights two to three metres away, in a room a few metres deep.** Light falls with the square of the distance: a light at half the distance needs a quarter of the power. A table-top scene with lights 60 cm from a small subject wants powers ten to twenty times smaller, and a lamp's `light` likewise. **When the first render is white, divide the powers by ten before touching anything else.** What else changes with size:

| | A person in a room (the sample) | A table top (things 10 to 30 cm, lights 0.5 m away) |
|---|---|---|
| key, rim `power` | 40 to 60, 100 to 170 | 2 to 6, 5 to 17 |
| a lamp's `light` | 8 at 1.7 m | 0.03 to 0.5 |
| `haze` | 0.06 | 0.2 to 0.6 (multiply by three metres over the depth of the set) |
| `aperture`, close shot | 0.010 to 0.016 | 0.003 to 0.004 |
| a spot's `angle` | 0.6 | 0.15 to 0.3, or it floods the table |

Camera moves, a lamp's halo and the hand-held tremor are sized from the scene itself (a share of the camera's distance, a multiple of the lamp's size), so they need no change.

## The house look

`src/house.js` holds the look NōTI finishes its own films with. A look that starts from it only has to add what the scene alone can know:

```js
import { houseLook } from '../src/house.js';
export default houseLook('dusk', {          // or 'night': the same room later, lamps only
  paint: { ... },                            // what each part is
  key: { from: [-2.4, 2.4, -1.2], at: 'head' },
  rim: { from: [1.5, 2.5, 2.6], at: 'head' },
  moves: [ ... ], sound: { ... },
});
```

Anything you write replaces the house's value for that one setting; the rest stays. These are the rules behind its numbers. Follow them even when the colours are the user's own, because they are what makes the frame read as shot rather than rendered.

1. **A warm room with one cool line.** Two colours of light do all the work: lamp amber (`warm`) and a single indigo (`cool`). Everything else is dark wood and near-black wall. A third colour appears only as a small object (a book spine, a mug), never as light.
2. **Lamps carry the picture.** Every warm area in the frame can be traced to a lamp you can see or believe is just out of shot. When a shadow is too dark, add a lamp or a low bounce (`lights`), not `fill`: fill is light from nowhere and it flattens the room.
3. **The key is a soft warm white, not orange.** Faces stay the colour of faces. The lamps are what is orange.
4. **The rim is far stronger than the key (two or three to one) and touches only an edge.** That balance looks wrong on paper and right on screen, because an edge is a few pixels wide. From a camera where the rim lights a whole side of the subject it is no longer a rim: switch it off for that camera (`not: ['over']`) and give that camera its own (`only: ['over']`). On a real set the lights are moved between set-ups for the same reason.
5. **The dark is warm.** The air is dark brown, never grey or blue, and the haze is thin: distance reads as warmth and depth, not as mist.
6. **Paint walls and floor neutral and dark, and let the lamp colour them.** A wall painted warm under a warm lamp goes red.
7. **Wood and plastic are a little glossy** (`rough` 0.35 to 0.5) so they catch a streak of lamp, and `reflect` puts the room itself into them.
8. **Glare belongs on the lamp, not across a face.** A lamp has a halo in the air round it; bloom stays low. If a face glows, lower the key.
9. **The lens is a squeezed one, and every effect of it is small:** out-of-focus lights are upright ovals, bright things leave a faint cool streak and a warm halo, straight lines bend slightly, colours part a little at the edges, blacks are never quite black, and there is grain. None of them should be the first thing you notice.
10. **Close-ups on a long lens** (a camera `fov` of 24 to 26) with the background melted; wides sharper.
11. **The camera is quiet.** Every shot moves slowly, no two neighbours alike; the first shot finds focus; the lens slams in once per film at most.
12. **Time of day changes what comes from outside, never the two colours.** `night` is `dusk` with less sky and stronger lamps. The warm lamps and the cool line are the identity; keep them through any change of hour.

**The user's own colours.** Keep the structure and change the palette: `houseLook('dusk', { palette: { warm: '#ffd27a', cool: '#19c3b1' } })`. One source colour, one opposite line, dark air. If their brand colour is strong, make it the line (the rim), not the room.

## 1. The scene file

A scene default-exports `duration`, `build()`, `update(t)`, `shots` and (optionally) `beats`. `scenes/sample.js` shows all of it in under 80 lines; copy it.

- `build({ THREE, scene, RoundedBoxGeometry })` makes the objects and returns `{ cameras, parts }`.
  - `parts` is `{ name: object }`: every thing the look should be able to paint, light or focus on. Name generously (`head`, `hair`, `screen`, `lamp`, `wall`): a part with no name can only take the look's `rest` colour. A part may sit inside another (`head` inside `person`).
  - `cameras` is `{ name: { pos: [x, y, z], look: [x, y, z], fov, focus: 'part name' } }`, in metres, y up. A camera that stands still is two points. A camera that travels in the animation itself (it rides beside a car, it follows someone) gives `pos` and `look` as functions of the second: `pos: (t) => [carX(t) - 0.3, 0.1, 0.4]`. That travel belongs to the animation, so the raw render has it too. What the look adds on top (a push, an arc) goes in the look.
- `update(t)` puts everything where it is at second `t`. It must depend on `t` alone (no counters, no "previous frame", no `Math.random()`, no clock): frames are drawn in any order and each one many times.
- `shots` is `[{ t, cam }]`: which camera is on from when. The first starts at 0.
- `beats` is `[{ t, kind, punch, key }]`: the moments that matter (a screen lights up, something lands, someone turns). `kind` is any word you choose; the sound map gives each kind its sound. `punch: 0.5` makes the camera react to it. `key: true` marks the one moment the film is about. A beat with `for: 5` is a sound that runs five seconds (wheels rolling, rain).
- A part that gives light can be dimmed or flashed by the animation: set `part.userData.glow` in `update` (1 is normal). The sample's screen does this.

**The user's own animation.** If they have three.js code already, do not rewrite it: wrap it. Find three things in their code and move them into a scene file: where the objects are created (that becomes `build`), what advances the animation (that becomes `update(t)`; if it steps by a frame delta, change it to compute from `t`), and where the camera sits (that becomes `cameras`). Use their geometry as it is. Remove their lights, their materials can stay (the look replaces them) and their render loop goes (the stage has its own). If their animation cannot be made a function of `t` (physics, user input), say so and ask whether to record its positions per frame first.

Their animation is the *before*. Do not improve the acting, the timing or the cut points while wrapping it; if something in it is broken, say so and ask.

## 2. Paint

- **Use the palette's names** (`warm`, `cool`, `dark`, `wood`) wherever a colour is one of them, so a change of palette changes the film.
- **The subject is the lightest thing; the room is darker and duller than the subject.** Walls and floor: neutral, dark. Skin, a face, the hero object: light. If the wall is as bright as the face, the eye has nowhere to go.
- **One strong colour, used once or twice** (a book spine, a mug). Everything else muted.
- `rough` is how matte a surface is: 0.8 to 0.95 for cloth, walls and skin; 0.35 to 0.5 for a desk top, plastic, a monitor.
- **Anything that would give light in life, glows**: a lamp shade, a screen, a window. `{ glow: 'warm', power: 2.4, light: 8, reach: 8, halo: 0.4 }` makes the part bright (`power`), makes it light the things near it (`light`, `reach`) and puts a soft halo in the air round it (`halo` is how strong, 0 for a flat screen; it is five times as wide as the part unless `haloSize`, in metres, says otherwise). A glow with no light in the room is a sticker.
  - `light` falls with the square of the distance. The sample's lamp is 1.7 m from the person and has 8; a bulb 40 cm above a head wants about 0.5; a small glowing thing held in a hand, 0.03.
  - The light sits at the part's centre and goes where the part goes. `lightAt: [x, y, z]` moves it off the centre (a screen lights from just in front of itself).
  - A glowing object that should still show its shape gets a `color` as well, and a lower `power`: glow alone is flat.
- `metal` (0 to 1) exists, but a metal shows only what it reflects: without `reflect` and a room with light in it, it goes black. For most things a low `rough` does the job.
- Everything not named takes `rest`. Run `compare` and look for anything still grey: it means a part was not named in the scene.

## 3. Light

- **Key**: put it to one side of the camera's view of the subject and above (`from`), aimed at the subject (`at: 'head'`). Never from where the camera is: front light is flat light. `power` 40 to 60 for a subject 3 metres away; the face should be bright but still show its form.
- **Rim**: behind the subject, on the *other* side from the key, in the cool colour, `power` 100 to 170. If you cannot see an edge of light on the subject, the rim is not behind them from this camera: move it. If it pours over the floor or the table instead of touching an edge, narrow its `angle`, aim it at the subject by name, and make that surface matte.
- **More lights** go in `lights`, each with a job you can say in a comment: `{ kind: 'point', from: [1.6, 0.5, 1.9], color: 'amber', power: 1.6 }` (a low bounce so a corner is dark but not empty), `{ kind: 'spot', from, at, color, power }` (an edge).
- **A light can belong to some cameras only**: `only: ['close']` or `not: ['over']`, on the key, the rim or any of `lights`. A scene has shots from several sides, and a rim for one camera is a front light for the camera opposite. Check every shot on the `compare` sheet; where one camera is spoiled, give it its own light. Keep the lamps the same in every shot: only the lights nobody can see may change.
- **Soft shadows**: `soft` 0.06 to 0.12 on the key. Hard-edged shadows look like a game, not a film.
- **Only the key casts shadows.** The rim, the lamps and every other light shine through walls and furniture. That is useful (a rim can stand behind a wall the subject leans on) and it is why a lamp can light the underside of a shelf it could not reach. Where that shows, lower that light or move it.
- **A light aimed at a part follows it** (`at: 'head'` stays on the head as they move). A point (`at: [0, 1.2, 0.7]`) stays put. A spot's `angle` is how wide it is, in radians (the key 0.6, the rim 0.7, any other spot 0.5 unless you say). A name that is not a part in the scene is reported when you render; read what the command prints.
- **A light that belongs to a lamp dims and flashes with it**: `key: { ..., with: 'shade' }`. Without that, a lamp can flicker while the face it lights stays bright.
- **Fill, haze**: the house values (`fill` 0.12, `haze` 0.06) suit a room a few metres deep. A bigger space wants less haze; if the picture turns to milk, halve it. `sky` and `ground` are the colours of the fill from above and from below.

## 4. Lens

- **Focus**: each camera names what it holds sharp (`focus: 'head'`). `aperture` is how fast everything else falls soft: 0.010 to 0.016 for a close-up (the background melts, something near the lens blurs), 0.004 to 0.008 for a wide, 0 for everything sharp. A shot sets its own in `moves` (`{ aperture: 0.007 }`).
- **Sub-frames**: every frame is the average of many slightly different ones, which is where motion blur, soft focus, soft shadows and clean edges all come from. `subframes: 16` for a final, `--n 4` for a draft. Fewer than 8 in a final shows as dots in the blur; a very soft shot may want 24.
- The rest of the lens comes from the house look and rarely needs touching. What each one is, if the user asks for more or less of it: `bloom` (light bleeding from bright things), `halation` (the warm halo round them), `streak` (the sideways streak; its colour follows the palette's `cool`), `oval` (how squeezed the out-of-focus lights are; 1 is round), `fringe` and `distortion` (the edges of the picture), `vignette`, `grain`, `contrast`, `saturation`, `split` (cool shadows, warm lights), `lift` (how far blacks sit off black), `fadeOut` (seconds of fade at the end).
- If one of them is the first thing you notice in the frame, halve it.
- Judge the lens on a full-size still (`stills 3.5`), not on a sheet: grain and focus do not survive being shrunk.

## 5. Camera

Moves go in the look's `moves` list, one entry per shot in the scene's order. `src/camera.js` lists them all. **A shot you give no entry gets one of six quiet house moves in turn** (a slow push, a small arc, a small sideways drift), so a film is never static and no two neighbours move alike. Write `{}` for a shot that should only breathe.

| Move | Use it when | A good number |
|---|---|---|
| `push` | something is about to happen, or just did: the room closes in | 0.05 to 0.1 |
| `push` negative | a reveal, or leaving someone alone | -0.05 |
| `arc` | showing what someone is looking at, or the space round them | 5 to 8 |
| `truck`, `crane` | sideways or up: following, or a quiet establishing shot | 0.01 to 0.03 |
| `hand` | tension, a reaction, anything close and human | 1 |
| `rack: { to: 'screen', at: 0.3 }` | the thing that matters changes inside one shot: focus leaves one part for another | |
| `vertigo` | once, on a realisation: the subject holds its size while the room stretches behind | 0.15 to 0.25 |
| `in: 'defocus'` | the first shot: the film arrives soft and finds focus | |
| `in: 'snap'` | cutting to a face on the line that turns the scene | |
| `in: 'whip'` | two shots that belong to one thought: a fast pan hides the cut | |
| `in: 'crash'` | once per film, on the biggest moment | |

- **One move per shot, two at most**, and say why in a comment beside it. A move without a reason is noise.
- **Slow.** A push of 0.1 over three seconds is already a lot. If you can see the camera moving on a sheet of eight frames, it is probably too fast.
- **Every amount is a share of the camera's distance to its subject (or an angle), never metres**, so the same numbers work on a table top and in a hall.
- A beat with `punch` makes the lens jump on that frame. Use it on one or two beats, not on all of them. Which beats punch is the scene's; how hard is the look's: `punch: 0.5` in the look halves every one of them, `punch: 0` switches them off.
- Raw and finished use the same cuts; only the finished one moves. That is the point of the before and after: do not move cut points to suit a move.

## 6. Sound

`node sound.mjs <name> plan` lists every cue: each cut, each arrival, each long push (0.05 or more, over 2.5 s or more), each beat, plus a room tone and music under everything. It also writes `out/<name>/cues.json`, and says when the music file is shorter than the film.

- **No sound files come with this kit.** Ask the user for their own, or tell them which kinds are needed (the plan says) and let them choose a library they have the right to use. Never invent a file, and never fetch sounds from the internet without the user choosing the source: licences differ. Suggest they keep a note of where each file came from.
- The look's `sound` list maps a kind to a file name in `sounds/`: `{ cut: 'whoosh', screen: 'blip', bed: 'room' }`. An entry can say more: `{ file: 'whoosh', lead: 0.2, level: 0.6 }`.

The rules the plan and the mix already follow, so you can explain them and keep to them when you adjust:

- **A movement sound starts before the cut and ends after it.** The ear arrives first and the cut feels motivated. Set `lead` to where the file's loudest point is, so that point sits on the cut.
- **A hit sits on the frame it happens, or one frame late. Never early**: an early sound reads as a mistake.
- **One sound per moment.** The plan warns when two fall within a tenth of a second: keep one.
- **One material per object.** If the mug is ceramic in the first shot, it is ceramic in the last.
- **No sound twice in a row.** The mix shifts a file's pitch and level a step when it comes back within ten seconds. With more than three cuts, also vary the kind: let some shots arrive with `in: 'snap'`, and let a cut pass in silence.
- **Music has a pulse**, even when it is calm, and it **breathes before the key moment**: the mix drops it for under half a second just before the beat marked `key` (or the one with the most `punch`). Never to silence: the room tone stays.
- **A voice sits well above the music.** Name the voice file as `voice` in the `sound` list and the music is lowered under it.
- **Density.** The plan prints sounds per second. A film with no speech holds attention at 2 to 4 a second; under speech, 0.5 to 1.5. Far below that, the scene needs more `beats` (footsteps, a chair, keys): ask the user which moments they are, do not invent action that is not in the animation.
- **The mix is set to -14 LUFS with peaks under -1.5 dB**, which is what phones and feeds expect. Where one sound is much louder than the rest the peaks stop it short of that, and the command says so: lower that sound's `level`.
- **A sound that lasts** (wheels, rain, a fan) is a beat with `for`: `{ t: 0.5, kind: 'roll', for: 5 }`. Its file is looped if it is shorter and faded at both ends.

`node sound.mjs <name> mix`, then `node render.mjs <name> video --audio out/<name>/sound.wav`.

You cannot hear. Say plainly that the mix is unheard and ask the user to listen once on a phone.

## What to look for

Open the image. Check each of these on every shot, in this order; fix the first one that fails, render again.

1. **Is anything still grey or flat-coloured?** A part was not named, or the key is not reaching it.
2. **Where does the eye go first?** It should be the subject's face or the thing the shot is about. If it is a lamp, a pale wall or a bright object on the desk: darken that, or brighten the subject.
3. **Is there a bright edge on the subject from behind?** No: move the rim. Is a whole side of them the rim's colour? It is not a rim from this camera: switch it off here and give this camera its own.
4. **Can you read the face?** Both eyes visible, one side lighter than the other, nothing blown out to white.
5. **Is the background darker and softer than the subject?** If not: darker walls, a wider aperture, less fill.
6. **Does every warm patch have a lamp?** A warm side of a face wants a lamp on that side of the room.
7. **Does the frame hold three tones** (a dark, a middle, a light) **and two colours** (warm and cool)? All middle is flat; all one colour is a tint.
8. **Has the room gone red, or the dark gone blue?** Red: the walls are painted too warm. Blue: the rim is reaching the walls, or `split` is too high.
9. **Has a table top or a floor gone white?** A glossy surface between the rim and a low camera mirrors the rim. Raise its `rough` towards 0.85, or move the rim.
10. **Is everything white, or is a lamp a white blob with a disc round it?** The powers are too high for this scene's size (see "Scale"): divide by ten. **Is the whole frame washed in a lamp's colour?** Its `haloSize` is far bigger than the thing: leave it out, or lower `halo`.
11. **Is something cut off or in the way?** A hand across the screen, a head touching the top edge. The framing belongs to the scene: tell the user rather than changing it.

Then the things one still cannot show. You cannot watch a video, so look at frames in a row: `node render.mjs <name> strip 4.4` draws eight consecutive frames from that second. Run it across every cut, on the fastest move, and wherever a light changes. Does each move start and end gently, does a cut land on a change of picture, does anything flicker (too few sub-frames), does a lamp that dims take its light with it?

## Deliver

- `node render.mjs <name> split`: the before and after, raw above and finished below, labelled. This is the proof; show it first. Each half is half the frame's height, so it cannot show the whole picture at the film's size. `--view` chooses: `0.5` shows exactly the film's width and the middle half of its height; `1` shows all of the height and twice the film's width; `0.72`, the default, sits between. Look at a frame of it from every shot. If the top or bottom of what a shot is about is cut off, raise it; if the edge of the set shows at the sides, lower it. `split draft` is the quick version, in its own file.
- `node render.mjs <name> video`: the finished film (add `--audio` once there is a mix).
- Tell the user where the files are, what the pass added in one sentence each (paint, light, lens, camera, sound), and what you could not judge: motion at speed and anything heard. Ask them to watch it once on a phone with the sound on.

## What you never do

- Never change the animation, its timing or its cuts as part of the pass. If the scene needs fixing, say what and ask.
- Never call a frame finished without having opened the picture.
- Never ship a look that only works from one camera: check every shot.
- Never add a sound the user has not supplied or chosen the source of.
